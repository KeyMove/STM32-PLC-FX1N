#ifndef __SYSTEM__H__
#define __SYSTEM__H__

#include "REG_MPC82G516.H"
#include "Uart.h"
#include "IAP.h"
#include "FX1N.h"


//Frequency Sysclk 12000000		11059200	22118400
//11059200
#define PLCTypeArrayLen		8		//	���Ϊ (PLCTypeArrayLenMAX-1)
#define PLCTypeArrayLenMAX	20		//	Ԥ��20���ֽ� 

#endif


