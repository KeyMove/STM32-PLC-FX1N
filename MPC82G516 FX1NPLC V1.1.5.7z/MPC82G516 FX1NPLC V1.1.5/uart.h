#ifndef __Uart__H__
#define __Uart__H__

#define SYSCLK			11059200
#define baud			9600		// ע���޸�Timer1 TH1

#define OutLEN			30			//	FIFO ���ͻ���������
#define InLEN			142			//	��ʱ�� ���ջ���������


extern volatile unsigned char UartSendBuffer[];
extern volatile unsigned char UartReceiveBuffer[];
extern volatile unsigned char *outlast;
extern volatile unsigned char *putlast;
extern volatile unsigned char UartSendBufferemptyFlag;
extern volatile unsigned char UartSendBufferHaveDataFlag;

extern volatile unsigned char UartReceiveCounter;
extern volatile unsigned char UartRxTimerStartFlag;
extern volatile unsigned char UartWaitForCounter;
extern volatile unsigned char UartDataReadyFlag;


//extern void UartInit(void);
extern void UartSendchar(unsigned char ucdata);
extern void UartSendString(unsigned char *str);
extern void UartSendByte(unsigned char *Startaddr,unsigned char SendByte);


#endif
