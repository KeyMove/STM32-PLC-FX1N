#ifndef __PLC51X_FNC__H__
#define __PLC51X_FNC__H__	 1

extern bit    CODE_ERROR;

extern code (*key_list[16])();
extern void CODE_scan (void);

extern volatile unsigned int  data  PS_BIT;                         //  P ָ��16���ݴ�
extern volatile unsigned int  data  PS1_BIT;                        //  P ָ��16���ݴ汸��
extern volatile unsigned int  data  Pi;                             //  P ָ��16���ݴ�λ��ָ��

//-------------------------------------------------------------------------------------//

#endif // __PLC51X_FNC__H__
