#ifndef __FX1N__H__
#define __FX1N__H__

//******************************************************************************//
//*                                                                            *//
//*     ����޸�PLC��[�洢����][2K\4K\8K],��ͬʱע���޸�[OrderSend3]������     *//
//*                                                                            *//
//******************************************************************************//
//	Ĭ�ϵ�ǰMPC82G516A������Ϊ
//	1K  ISP Code
//	31K	IAP Code
//	32K Flash Code

#define MCUFLASHSIZE		64*1024								//	64K
#define MCUIAPFLASHSIZE		31*1024								//	31K
#define MCUISPFLASHSIZE		1*1024								//	1K
#define PLCIAPCODEAddr		(MCUFLASHSIZE-MCUIAPFLASHSIZE-MCUISPFLASHSIZE)
#define PLCSTEP			    8000								//	��ǰ[�洢����]Ϊ8K.
#define PLCTypeAddr			(MCUFLASHSIZE-MCUISPFLASHSIZE-512)	//	��IAP������һҳ.

//==========================================
//
#define ENQ 	0x05			//����  
#define ACK 	0x06	 		//PLC ������ȷ��Ӧ  
#define NACK 	0x15 			//PLC ���մ�����Ӧ 
#define STX 	0x02 			//���Ŀ�ʼ
#define ETX 	0x03	 		//���Ľ���  
// STX ,CMD ,ADDRESS, BYTES, ETX, SUM 
// 02H, 30H, 31H,30H,46H,36H, 30H,34H, 03H, 37H,34H 
// SUM=CMD+......+ETX  
// 30h+31h+30h+46h+36h+30h+34h+03h=74h; 
// �ۼӺͳ�����λȡ����λ
//
//===========================================
#define	ErasureALL		0
#define ErasureCODE		1



extern unsigned char code OrderSend1[];
extern unsigned char code OrderSend2[];
extern unsigned char code OrderSend3[];
extern unsigned char code OrderSend4[];
extern unsigned char code OrderSend5[];
extern unsigned char code OrderSend6[];
extern unsigned char code OrderSend7[];
extern unsigned char code OrderSend8[];
extern unsigned char code OrderSend9[];
extern unsigned char code OrderSend10[];


extern unsigned int hextoasc(unsigned char hexdata);
extern unsigned char asctohex(unsigned char *ascdata);
extern unsigned char ascto0F(unsigned char ucdata);
extern void ErasurePLC(unsigned char allorcode);
extern void WriteFlash(unsigned int WriteAddr,unsigned char *Buf,unsigned int WriteLen);
extern unsigned char sumcheck(unsigned char *Startaddr,unsigned char checklen);
extern void FX1NProcessing(void);


#endif
