﻿using KeyMove.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KControl
{
    class IOPort
    {

        static UartProtocol UP;
        public static int InputCount
        {
            get; set;
        }

        public static int OutputCount
        {
            get; set;
        }

        public static void Init(UartProtocol up)
        {
            UP = up;
        }

        public static void SetIO(byte[] data)
        {
            if (UP.isLink)
            {
                ByteStream b = new ByteStream(32);
                b.WriteByte(OutputCount);
                b.WriteBuff(data);
                UP.SendDataPacket(UartProtocol.PacketCmd.SetOutputPort, b.toBytes());
            }
        }

    }
}
