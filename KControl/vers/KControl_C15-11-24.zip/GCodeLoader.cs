﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KControl
{
    public partial class GCodeLoader : Form
    {

        Bitmap map = new Bitmap(600, 600);
        Graphics g;
        Graphics draw;
        public GCodeLoader()
        {
            InitializeComponent();
        }
        OpenFileDialog of = new OpenFileDialog();
        private void OpenGCode_Click(object sender, EventArgs e)
        {
            of.Filter = "";
        }

        public bool LoadFile(string file, double X, double Y, double Z, double N, double O, double A)
        {
            oX = this.X = X;
            oY = this.Y = Y;
            oZ = this.Z = Z;
            this.N = N;
            this.O = O;
            this.A = A;
            DecodeGCode(file);
            return true;
        }
        List<double[]> AngleList = new List<double[]>();
        double[] LastAngle;
        double XnPos, YnPos, ZnPos;
        double X, Y, Z,N,O,A;
        List<double> PosXList = new List<double>();
        List<double> PosYList = new List<double>();
        List<double> PosZList = new List<double>();
        private void GCodeLoader_Load(object sender, EventArgs e)
        {
            g = Graphics.FromImage(map);
            draw = pictureBox1.CreateGraphics();
        }

        double oX, oY, oZ;
        int GetNum(string p, int offset)
        {
            int x = 0;
            bool fv = false;
            int index = offset;
            while ((p[index] < ('9' + 1) && p[index] > ('0' - 1)) || p[index] == '-')
            {
                if (p[index] == '-')
                {
                    index++;
                    fv = true;
                    continue;
                }
                x *= 10;
                x += p[index] - '0';
                index++;
                if (p.Length <= index)
                    return (fv) ? -x : x;
            }
            return (fv) ? -x : x;
        }

        public List<double[]> getData()
        {
            return AngleList;
        }

        public double[] getXList()
        {
            return PosXList.ToArray();
        }

        public double[] getYList()
        {
            return PosYList.ToArray();
        }

        public double[] getZList()
        {
            return PosZList.ToArray();
        }

        void DecodeGCode(string filename, double sacl = 0.25,double xscal=1,double yscal=1,double zscal=1)
        {
            double x, y, z;
            string GCodeString = string.Empty;
            try
            {
                GCodeString = new System.IO.StreamReader(filename).ReadToEnd();
            }
            catch { return; }
            bool Grid = false;
            int index = 0;
            int GCodeID = 0;
            if (GCodeString == string.Empty)
                return;
            XnPos = 0;
            YnPos = 0;
            ZnPos = 0;
            PosXList.Clear();
            PosYList.Clear();
            PosZList.Clear();
            LastAngle = new double[6] {0,0,0,0,0,0 };
            while (index != -1)
            {
                if (Grid)
                {
                    x = 0;
                    y = 0;
                    z = 0;
                }
                else
                {
                    x = XnPos;
                    y = YnPos;
                    z = ZnPos;
                }
                while (GCodeString[index] != '\n')
                {
                    switch (GCodeString[index++])
                    {
                        case 'D':

                            break;
                        case 'F':

                            break;
                        case 'G':
                            GCodeID = GetNum(GCodeString, index);
                            break;
                        case 'X':
                            x = GetNum(GCodeString, index);
                            break;
                        case 'Y':
                            y = GetNum(GCodeString, index);
                            break;
                        case 'Z':
                            z = GetNum(GCodeString, index);
                            break;
                    }
                    if (index >= GCodeString.Length)
                    {
                        index = -1;
                        break;
                    }
                }
                if (Grid)
                {
                    x += XnPos;
                    y += YnPos;
                    z += ZnPos;
                }
                if (index != -1)
                    if (GCodeString[index] == '\n')
                        index++;
                if (index >= GCodeString.Length)
                {
                    index = -1;
                }

                X = x / 1000 * sacl;
                Y = y / 1000 * sacl;
                Z = z / 1000 * sacl;
                X *= xscal;
                Y *= yscal;
                Z *= zscal;

                switch (GCodeID)
                {
                    case 0:
                    case 1:
                        PosXList.Add(X+oX);
                        PosYList.Add(Y+oY);
                        PosZList.Add(Z+oZ);
                        //Axis6.AxisStruct posdata = new Axis6.AxisStruct(X+oX, Y+oY, Z+oZ, N, O, A, new double[] { 0, 0, 0, 0, 0, 0 });
                        //double[] angle = Axis6.PosToAngle(LastAngle, X + oX, Y + oY, Z + oZ, N, O, A);
                        //if (angle != null)
                        //{
                        //    LastAngle = angle;
                        //    AngleList.Add(angle);
                        //}
                        break;
                    case 2: break;
                    case 3: break;
                    case 90:
                        Grid = false;
                        break;
                    case 91:
                        Grid = true;
                        break;
                    default:
                        break;
                }
                XnPos = x;
                YnPos = y;
                ZnPos = z;
            }
            //BuildGcode();
        }
    }
}
