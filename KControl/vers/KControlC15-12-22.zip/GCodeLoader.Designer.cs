﻿namespace KControl
{
    partial class GCodeLoader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UIPanel = new System.Windows.Forms.Panel();
            this.label52 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CodeBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.UIPanel2 = new System.Windows.Forms.Panel();
            this.label74 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.UIPanel3 = new System.Windows.Forms.Panel();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.UIPanel4 = new System.Windows.Forms.Panel();
            this.label128 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox62 = new System.Windows.Forms.PictureBox();
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox65 = new System.Windows.Forms.PictureBox();
            this.pictureBox66 = new System.Windows.Forms.PictureBox();
            this.pictureBox67 = new System.Windows.Forms.PictureBox();
            this.pictureBox68 = new System.Windows.Forms.PictureBox();
            this.pictureBox69 = new System.Windows.Forms.PictureBox();
            this.pictureBox70 = new System.Windows.Forms.PictureBox();
            this.pictureBox71 = new System.Windows.Forms.PictureBox();
            this.pictureBox72 = new System.Windows.Forms.PictureBox();
            this.pictureBox73 = new System.Windows.Forms.PictureBox();
            this.pictureBox74 = new System.Windows.Forms.PictureBox();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.label103 = new System.Windows.Forms.Label();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.label112 = new System.Windows.Forms.Label();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox75 = new System.Windows.Forms.PictureBox();
            this.pictureBox76 = new System.Windows.Forms.PictureBox();
            this.pictureBox77 = new System.Windows.Forms.PictureBox();
            this.pictureBox78 = new System.Windows.Forms.PictureBox();
            this.pictureBox79 = new System.Windows.Forms.PictureBox();
            this.label77 = new System.Windows.Forms.Label();
            this.pictureBox80 = new System.Windows.Forms.PictureBox();
            this.label78 = new System.Windows.Forms.Label();
            this.pictureBox81 = new System.Windows.Forms.PictureBox();
            this.UIPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.UIPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.UIPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.UIPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).BeginInit();
            this.SuspendLayout();
            // 
            // UIPanel
            // 
            this.UIPanel.Controls.Add(this.label52);
            this.UIPanel.Controls.Add(this.label44);
            this.UIPanel.Controls.Add(this.label36);
            this.UIPanel.Controls.Add(this.label59);
            this.UIPanel.Controls.Add(this.label51);
            this.UIPanel.Controls.Add(this.label43);
            this.UIPanel.Controls.Add(this.label32);
            this.UIPanel.Controls.Add(this.label58);
            this.UIPanel.Controls.Add(this.label50);
            this.UIPanel.Controls.Add(this.label42);
            this.UIPanel.Controls.Add(this.label35);
            this.UIPanel.Controls.Add(this.label57);
            this.UIPanel.Controls.Add(this.label49);
            this.UIPanel.Controls.Add(this.label41);
            this.UIPanel.Controls.Add(this.label31);
            this.UIPanel.Controls.Add(this.label56);
            this.UIPanel.Controls.Add(this.label48);
            this.UIPanel.Controls.Add(this.label40);
            this.UIPanel.Controls.Add(this.label34);
            this.UIPanel.Controls.Add(this.pictureBox30);
            this.UIPanel.Controls.Add(this.pictureBox22);
            this.UIPanel.Controls.Add(this.pictureBox14);
            this.UIPanel.Controls.Add(this.label55);
            this.UIPanel.Controls.Add(this.label47);
            this.UIPanel.Controls.Add(this.label39);
            this.UIPanel.Controls.Add(this.label18);
            this.UIPanel.Controls.Add(this.label54);
            this.UIPanel.Controls.Add(this.label46);
            this.UIPanel.Controls.Add(this.label38);
            this.UIPanel.Controls.Add(this.label33);
            this.UIPanel.Controls.Add(this.pictureBox37);
            this.UIPanel.Controls.Add(this.pictureBox29);
            this.UIPanel.Controls.Add(this.pictureBox21);
            this.UIPanel.Controls.Add(this.pictureBox10);
            this.UIPanel.Controls.Add(this.pictureBox36);
            this.UIPanel.Controls.Add(this.pictureBox28);
            this.UIPanel.Controls.Add(this.pictureBox20);
            this.UIPanel.Controls.Add(this.pictureBox13);
            this.UIPanel.Controls.Add(this.label53);
            this.UIPanel.Controls.Add(this.label45);
            this.UIPanel.Controls.Add(this.label37);
            this.UIPanel.Controls.Add(this.label17);
            this.UIPanel.Controls.Add(this.pictureBox35);
            this.UIPanel.Controls.Add(this.pictureBox27);
            this.UIPanel.Controls.Add(this.pictureBox19);
            this.UIPanel.Controls.Add(this.pictureBox12);
            this.UIPanel.Controls.Add(this.pictureBox34);
            this.UIPanel.Controls.Add(this.pictureBox26);
            this.UIPanel.Controls.Add(this.pictureBox18);
            this.UIPanel.Controls.Add(this.pictureBox9);
            this.UIPanel.Controls.Add(this.pictureBox33);
            this.UIPanel.Controls.Add(this.pictureBox32);
            this.UIPanel.Controls.Add(this.pictureBox25);
            this.UIPanel.Controls.Add(this.pictureBox24);
            this.UIPanel.Controls.Add(this.pictureBox17);
            this.UIPanel.Controls.Add(this.pictureBox31);
            this.UIPanel.Controls.Add(this.pictureBox16);
            this.UIPanel.Controls.Add(this.pictureBox23);
            this.UIPanel.Controls.Add(this.pictureBox11);
            this.UIPanel.Controls.Add(this.pictureBox15);
            this.UIPanel.Controls.Add(this.pictureBox8);
            this.UIPanel.Controls.Add(this.pictureBox7);
            this.UIPanel.Controls.Add(this.label15);
            this.UIPanel.Controls.Add(this.label8);
            this.UIPanel.Controls.Add(this.label14);
            this.UIPanel.Controls.Add(this.label5);
            this.UIPanel.Controls.Add(this.label13);
            this.UIPanel.Controls.Add(this.label7);
            this.UIPanel.Controls.Add(this.label12);
            this.UIPanel.Controls.Add(this.label4);
            this.UIPanel.Controls.Add(this.label11);
            this.UIPanel.Controls.Add(this.label30);
            this.UIPanel.Controls.Add(this.label28);
            this.UIPanel.Controls.Add(this.label27);
            this.UIPanel.Controls.Add(this.label26);
            this.UIPanel.Controls.Add(this.label25);
            this.UIPanel.Controls.Add(this.label24);
            this.UIPanel.Controls.Add(this.label29);
            this.UIPanel.Controls.Add(this.label23);
            this.UIPanel.Controls.Add(this.label22);
            this.UIPanel.Controls.Add(this.label21);
            this.UIPanel.Controls.Add(this.label20);
            this.UIPanel.Controls.Add(this.label19);
            this.UIPanel.Controls.Add(this.label6);
            this.UIPanel.Controls.Add(this.label10);
            this.UIPanel.Controls.Add(this.label3);
            this.UIPanel.Controls.Add(this.label9);
            this.UIPanel.Controls.Add(this.label16);
            this.UIPanel.Controls.Add(this.label2);
            this.UIPanel.Controls.Add(this.pictureBox6);
            this.UIPanel.Controls.Add(this.pictureBox4);
            this.UIPanel.Controls.Add(this.pictureBox3);
            this.UIPanel.Controls.Add(this.pictureBox2);
            this.UIPanel.Controls.Add(this.pictureBox5);
            this.UIPanel.Controls.Add(this.pictureBox1);
            this.UIPanel.Location = new System.Drawing.Point(0, 0);
            this.UIPanel.Name = "UIPanel";
            this.UIPanel.Size = new System.Drawing.Size(480, 320);
            this.UIPanel.TabIndex = 0;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.SystemColors.Control;
            this.label52.Font = new System.Drawing.Font("宋体", 12F);
            this.label52.Location = new System.Drawing.Point(433, 201);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(32, 16);
            this.label52.TabIndex = 3;
            this.label52.Text = "I16";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.SystemColors.Control;
            this.label44.Font = new System.Drawing.Font("宋体", 12F);
            this.label44.Location = new System.Drawing.Point(436, 147);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(24, 16);
            this.label44.TabIndex = 3;
            this.label44.Text = "I8";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.SystemColors.Control;
            this.label36.Font = new System.Drawing.Font("宋体", 12F);
            this.label36.Location = new System.Drawing.Point(437, 68);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(24, 16);
            this.label36.TabIndex = 3;
            this.label36.Text = "O8";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.SystemColors.Control;
            this.label59.Font = new System.Drawing.Font("宋体", 12F);
            this.label59.Location = new System.Drawing.Point(279, 255);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(32, 16);
            this.label59.TabIndex = 3;
            this.label59.Text = "I20";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.SystemColors.Control;
            this.label51.Font = new System.Drawing.Font("宋体", 12F);
            this.label51.Location = new System.Drawing.Point(279, 201);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(32, 16);
            this.label51.TabIndex = 3;
            this.label51.Text = "I12";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.SystemColors.Control;
            this.label43.Font = new System.Drawing.Font("宋体", 12F);
            this.label43.Location = new System.Drawing.Point(282, 147);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(24, 16);
            this.label43.TabIndex = 3;
            this.label43.Text = "I4";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.SystemColors.Control;
            this.label32.Font = new System.Drawing.Font("宋体", 12F);
            this.label32.Location = new System.Drawing.Point(283, 68);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(24, 16);
            this.label32.TabIndex = 3;
            this.label32.Text = "O4";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.SystemColors.Control;
            this.label58.Font = new System.Drawing.Font("宋体", 12F);
            this.label58.Location = new System.Drawing.Point(395, 255);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(32, 16);
            this.label58.TabIndex = 3;
            this.label58.Text = "I23";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.SystemColors.Control;
            this.label50.Font = new System.Drawing.Font("宋体", 12F);
            this.label50.Location = new System.Drawing.Point(394, 201);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(32, 16);
            this.label50.TabIndex = 3;
            this.label50.Text = "I15";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.SystemColors.Control;
            this.label42.Font = new System.Drawing.Font("宋体", 12F);
            this.label42.Location = new System.Drawing.Point(398, 147);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(24, 16);
            this.label42.TabIndex = 3;
            this.label42.Text = "I7";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.SystemColors.Control;
            this.label35.Font = new System.Drawing.Font("宋体", 12F);
            this.label35.Location = new System.Drawing.Point(399, 68);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(24, 16);
            this.label35.TabIndex = 3;
            this.label35.Text = "O7";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.SystemColors.Control;
            this.label57.Font = new System.Drawing.Font("宋体", 12F);
            this.label57.Location = new System.Drawing.Point(241, 255);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(32, 16);
            this.label57.TabIndex = 3;
            this.label57.Text = "I19";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.SystemColors.Control;
            this.label49.Font = new System.Drawing.Font("宋体", 12F);
            this.label49.Location = new System.Drawing.Point(241, 201);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(32, 16);
            this.label49.TabIndex = 3;
            this.label49.Text = "I11";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.SystemColors.Control;
            this.label41.Font = new System.Drawing.Font("宋体", 12F);
            this.label41.Location = new System.Drawing.Point(244, 147);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(24, 16);
            this.label41.TabIndex = 3;
            this.label41.Text = "I3";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.Control;
            this.label31.Font = new System.Drawing.Font("宋体", 12F);
            this.label31.Location = new System.Drawing.Point(245, 68);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(24, 16);
            this.label31.TabIndex = 3;
            this.label31.Text = "O3";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.SystemColors.Control;
            this.label56.Font = new System.Drawing.Font("宋体", 12F);
            this.label56.Location = new System.Drawing.Point(357, 255);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(32, 16);
            this.label56.TabIndex = 3;
            this.label56.Text = "I22";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.SystemColors.Control;
            this.label48.Font = new System.Drawing.Font("宋体", 12F);
            this.label48.Location = new System.Drawing.Point(356, 201);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(32, 16);
            this.label48.TabIndex = 3;
            this.label48.Text = "I14";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.Control;
            this.label40.Font = new System.Drawing.Font("宋体", 12F);
            this.label40.Location = new System.Drawing.Point(360, 147);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(24, 16);
            this.label40.TabIndex = 3;
            this.label40.Text = "I6";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.SystemColors.Control;
            this.label34.Font = new System.Drawing.Font("宋体", 12F);
            this.label34.Location = new System.Drawing.Point(361, 68);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(24, 16);
            this.label34.TabIndex = 3;
            this.label34.Text = "O6";
            // 
            // pictureBox30
            // 
            this.pictureBox30.BackColor = System.Drawing.Color.Red;
            this.pictureBox30.Location = new System.Drawing.Point(432, 166);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(32, 32);
            this.pictureBox30.TabIndex = 2;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Tag = "Value&BIT15";
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackColor = System.Drawing.Color.Red;
            this.pictureBox22.Location = new System.Drawing.Point(432, 112);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(32, 32);
            this.pictureBox22.TabIndex = 2;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Tag = "Value&BIT7";
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.Red;
            this.pictureBox14.Location = new System.Drawing.Point(433, 33);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(32, 32);
            this.pictureBox14.TabIndex = 2;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Tag = "Value&BIT7";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.SystemColors.Control;
            this.label55.Font = new System.Drawing.Font("宋体", 12F);
            this.label55.Location = new System.Drawing.Point(203, 255);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(32, 16);
            this.label55.TabIndex = 3;
            this.label55.Text = "I18";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.SystemColors.Control;
            this.label47.Font = new System.Drawing.Font("宋体", 12F);
            this.label47.Location = new System.Drawing.Point(202, 201);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(32, 16);
            this.label47.TabIndex = 3;
            this.label47.Text = "I10";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.SystemColors.Control;
            this.label39.Font = new System.Drawing.Font("宋体", 12F);
            this.label39.Location = new System.Drawing.Point(206, 147);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(24, 16);
            this.label39.TabIndex = 3;
            this.label39.Text = "I2";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.Control;
            this.label18.Font = new System.Drawing.Font("宋体", 12F);
            this.label18.Location = new System.Drawing.Point(207, 68);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(24, 16);
            this.label18.TabIndex = 3;
            this.label18.Text = "O2";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.SystemColors.Control;
            this.label54.Font = new System.Drawing.Font("宋体", 12F);
            this.label54.Location = new System.Drawing.Point(319, 255);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(32, 16);
            this.label54.TabIndex = 3;
            this.label54.Text = "I21";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.SystemColors.Control;
            this.label46.Font = new System.Drawing.Font("宋体", 12F);
            this.label46.Location = new System.Drawing.Point(318, 201);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(32, 16);
            this.label46.TabIndex = 3;
            this.label46.Text = "I13";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.SystemColors.Control;
            this.label38.Font = new System.Drawing.Font("宋体", 12F);
            this.label38.Location = new System.Drawing.Point(322, 147);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(24, 16);
            this.label38.TabIndex = 3;
            this.label38.Text = "I5";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.SystemColors.Control;
            this.label33.Font = new System.Drawing.Font("宋体", 12F);
            this.label33.Location = new System.Drawing.Point(323, 68);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(24, 16);
            this.label33.TabIndex = 3;
            this.label33.Text = "O5";
            // 
            // pictureBox37
            // 
            this.pictureBox37.BackColor = System.Drawing.Color.Red;
            this.pictureBox37.Location = new System.Drawing.Point(278, 220);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(32, 32);
            this.pictureBox37.TabIndex = 2;
            this.pictureBox37.TabStop = false;
            this.pictureBox37.Tag = "Value&BIT19";
            // 
            // pictureBox29
            // 
            this.pictureBox29.BackColor = System.Drawing.Color.Red;
            this.pictureBox29.Location = new System.Drawing.Point(278, 166);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(32, 32);
            this.pictureBox29.TabIndex = 2;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Tag = "Value&BIT11";
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.Red;
            this.pictureBox21.Location = new System.Drawing.Point(278, 112);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(32, 32);
            this.pictureBox21.TabIndex = 2;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Tag = "Value&BIT3";
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.Red;
            this.pictureBox10.Location = new System.Drawing.Point(279, 33);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(32, 32);
            this.pictureBox10.TabIndex = 2;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Tag = "Value&BIT3";
            // 
            // pictureBox36
            // 
            this.pictureBox36.BackColor = System.Drawing.Color.Lime;
            this.pictureBox36.Location = new System.Drawing.Point(394, 220);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(32, 32);
            this.pictureBox36.TabIndex = 2;
            this.pictureBox36.TabStop = false;
            this.pictureBox36.Tag = "Value&BIT22";
            // 
            // pictureBox28
            // 
            this.pictureBox28.BackColor = System.Drawing.Color.Lime;
            this.pictureBox28.Location = new System.Drawing.Point(394, 166);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(32, 32);
            this.pictureBox28.TabIndex = 2;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Tag = "Value&BIT14";
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.Lime;
            this.pictureBox20.Location = new System.Drawing.Point(394, 112);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(32, 32);
            this.pictureBox20.TabIndex = 2;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Tag = "Value&BIT6";
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.Lime;
            this.pictureBox13.Location = new System.Drawing.Point(395, 33);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(32, 32);
            this.pictureBox13.TabIndex = 2;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Tag = "Value&BIT6";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.SystemColors.Control;
            this.label53.Font = new System.Drawing.Font("宋体", 12F);
            this.label53.Location = new System.Drawing.Point(165, 255);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(32, 16);
            this.label53.TabIndex = 3;
            this.label53.Text = "I17";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.SystemColors.Control;
            this.label45.Font = new System.Drawing.Font("宋体", 12F);
            this.label45.Location = new System.Drawing.Point(168, 201);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(24, 16);
            this.label45.TabIndex = 3;
            this.label45.Text = "I9";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.SystemColors.Control;
            this.label37.Font = new System.Drawing.Font("宋体", 12F);
            this.label37.Location = new System.Drawing.Point(168, 147);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(24, 16);
            this.label37.TabIndex = 3;
            this.label37.Text = "I1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.Control;
            this.label17.Font = new System.Drawing.Font("宋体", 12F);
            this.label17.Location = new System.Drawing.Point(169, 68);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(24, 16);
            this.label17.TabIndex = 3;
            this.label17.Text = "O1";
            // 
            // pictureBox35
            // 
            this.pictureBox35.BackColor = System.Drawing.Color.Red;
            this.pictureBox35.Location = new System.Drawing.Point(356, 220);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(32, 32);
            this.pictureBox35.TabIndex = 2;
            this.pictureBox35.TabStop = false;
            this.pictureBox35.Tag = "Value&BIT21";
            // 
            // pictureBox27
            // 
            this.pictureBox27.BackColor = System.Drawing.Color.Red;
            this.pictureBox27.Location = new System.Drawing.Point(356, 166);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(32, 32);
            this.pictureBox27.TabIndex = 2;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Tag = "Value&BIT13";
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.Red;
            this.pictureBox19.Location = new System.Drawing.Point(356, 112);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(32, 32);
            this.pictureBox19.TabIndex = 2;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Tag = "Value&BIT5";
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.Red;
            this.pictureBox12.Location = new System.Drawing.Point(357, 33);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(32, 32);
            this.pictureBox12.TabIndex = 2;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Tag = "Value&BIT5";
            // 
            // pictureBox34
            // 
            this.pictureBox34.BackColor = System.Drawing.Color.Lime;
            this.pictureBox34.Location = new System.Drawing.Point(240, 220);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(32, 32);
            this.pictureBox34.TabIndex = 2;
            this.pictureBox34.TabStop = false;
            this.pictureBox34.Tag = "Value&BIT18";
            // 
            // pictureBox26
            // 
            this.pictureBox26.BackColor = System.Drawing.Color.Lime;
            this.pictureBox26.Location = new System.Drawing.Point(240, 166);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(32, 32);
            this.pictureBox26.TabIndex = 2;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Tag = "Value&BIT10";
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.Lime;
            this.pictureBox18.Location = new System.Drawing.Point(240, 112);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(32, 32);
            this.pictureBox18.TabIndex = 2;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Tag = "Value&BIT2";
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Lime;
            this.pictureBox9.Location = new System.Drawing.Point(241, 33);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(32, 32);
            this.pictureBox9.TabIndex = 2;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Tag = "Value&BIT2";
            // 
            // pictureBox33
            // 
            this.pictureBox33.BackColor = System.Drawing.Color.Lime;
            this.pictureBox33.Location = new System.Drawing.Point(318, 220);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(32, 32);
            this.pictureBox33.TabIndex = 2;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.Tag = "Value&BIT20";
            // 
            // pictureBox32
            // 
            this.pictureBox32.BackColor = System.Drawing.Color.Red;
            this.pictureBox32.Location = new System.Drawing.Point(202, 220);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(32, 32);
            this.pictureBox32.TabIndex = 2;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Tag = "Value&BIT17";
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.Color.Lime;
            this.pictureBox25.Location = new System.Drawing.Point(318, 166);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(32, 32);
            this.pictureBox25.TabIndex = 2;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Tag = "Value&BIT12";
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.Color.Red;
            this.pictureBox24.Location = new System.Drawing.Point(202, 166);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(32, 32);
            this.pictureBox24.TabIndex = 2;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Tag = "Value&BIT9";
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.Lime;
            this.pictureBox17.Location = new System.Drawing.Point(318, 112);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(32, 32);
            this.pictureBox17.TabIndex = 2;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Tag = "Value&BIT4";
            // 
            // pictureBox31
            // 
            this.pictureBox31.BackColor = System.Drawing.Color.Lime;
            this.pictureBox31.Location = new System.Drawing.Point(164, 220);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(32, 32);
            this.pictureBox31.TabIndex = 2;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Tag = "Value&BIT16";
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.Red;
            this.pictureBox16.Location = new System.Drawing.Point(202, 112);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(32, 32);
            this.pictureBox16.TabIndex = 2;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Tag = "Value&BIT1";
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.Color.Lime;
            this.pictureBox23.Location = new System.Drawing.Point(164, 166);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(32, 32);
            this.pictureBox23.TabIndex = 2;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Tag = "Value&BIT8";
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Lime;
            this.pictureBox11.Location = new System.Drawing.Point(319, 33);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(32, 32);
            this.pictureBox11.TabIndex = 2;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Tag = "Value&BIT4";
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.Lime;
            this.pictureBox15.Location = new System.Drawing.Point(164, 112);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(32, 32);
            this.pictureBox15.TabIndex = 2;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Tag = "Value2&BIT0";
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Red;
            this.pictureBox8.Location = new System.Drawing.Point(203, 33);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(32, 32);
            this.pictureBox8.TabIndex = 2;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Tag = "Value&BIT1";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Lime;
            this.pictureBox7.Location = new System.Drawing.Point(165, 33);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(32, 32);
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Tag = "Value&BIT0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.Control;
            this.label15.Font = new System.Drawing.Font("宋体", 12F);
            this.label15.Location = new System.Drawing.Point(11, 231);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 16);
            this.label15.TabIndex = 0;
            this.label15.Text = "第3轴:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.Font = new System.Drawing.Font("宋体", 12F);
            this.label8.Location = new System.Drawing.Point(11, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "Z:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.Control;
            this.label14.Font = new System.Drawing.Font("宋体", 12F);
            this.label14.Location = new System.Drawing.Point(11, 294);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 16);
            this.label14.TabIndex = 0;
            this.label14.Text = "第6轴:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Font = new System.Drawing.Font("宋体", 12F);
            this.label5.Location = new System.Drawing.Point(11, 134);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "A:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.Control;
            this.label13.Font = new System.Drawing.Font("宋体", 12F);
            this.label13.Location = new System.Drawing.Point(11, 210);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 16);
            this.label13.TabIndex = 0;
            this.label13.Text = "第2轴:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.Control;
            this.label7.Font = new System.Drawing.Font("宋体", 12F);
            this.label7.Location = new System.Drawing.Point(11, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Y:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.Control;
            this.label12.Font = new System.Drawing.Font("宋体", 12F);
            this.label12.Location = new System.Drawing.Point(11, 273);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 16);
            this.label12.TabIndex = 0;
            this.label12.Text = "第5轴:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Font = new System.Drawing.Font("宋体", 12F);
            this.label4.Location = new System.Drawing.Point(11, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "O:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.Control;
            this.label11.Font = new System.Drawing.Font("宋体", 12F);
            this.label11.Location = new System.Drawing.Point(11, 189);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "第1轴:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.SystemColors.Control;
            this.label30.Font = new System.Drawing.Font("宋体", 12F);
            this.label30.Location = new System.Drawing.Point(73, 210);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(16, 16);
            this.label30.TabIndex = 0;
            this.label30.Tag = "Value[7],Value2[7],3,2";
            this.label30.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.SystemColors.Control;
            this.label28.Font = new System.Drawing.Font("宋体", 12F);
            this.label28.Location = new System.Drawing.Point(73, 294);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(16, 16);
            this.label28.TabIndex = 0;
            this.label28.Tag = "Value[11],Value2[11],3,2";
            this.label28.Text = "0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.Control;
            this.label27.Font = new System.Drawing.Font("宋体", 12F);
            this.label27.Location = new System.Drawing.Point(73, 273);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(16, 16);
            this.label27.TabIndex = 0;
            this.label27.Tag = "Value[10],Value2[10],3,2";
            this.label27.Text = "0";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.Control;
            this.label26.Font = new System.Drawing.Font("宋体", 12F);
            this.label26.Location = new System.Drawing.Point(73, 252);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(16, 16);
            this.label26.TabIndex = 0;
            this.label26.Tag = "Value[9],Value2[9],3,2";
            this.label26.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.Control;
            this.label25.Font = new System.Drawing.Font("宋体", 12F);
            this.label25.Location = new System.Drawing.Point(73, 231);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(16, 16);
            this.label25.TabIndex = 0;
            this.label25.Tag = "Value[8],Value2[8],3,2";
            this.label25.Text = "0";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.Control;
            this.label24.Font = new System.Drawing.Font("宋体", 12F);
            this.label24.Location = new System.Drawing.Point(73, 189);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(16, 16);
            this.label24.TabIndex = 0;
            this.label24.Tag = "Value[6],Value2[6],3,2";
            this.label24.Text = "0";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.SystemColors.Control;
            this.label29.Font = new System.Drawing.Font("宋体", 12F);
            this.label29.Location = new System.Drawing.Point(41, 134);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(16, 16);
            this.label29.TabIndex = 0;
            this.label29.Tag = "Value[5],Value2[5],4,3";
            this.label29.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.Control;
            this.label23.Font = new System.Drawing.Font("宋体", 12F);
            this.label23.Location = new System.Drawing.Point(41, 113);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(16, 16);
            this.label23.TabIndex = 0;
            this.label23.Tag = "Value[4],Value2[4],4,3";
            this.label23.Text = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.Control;
            this.label22.Font = new System.Drawing.Font("宋体", 12F);
            this.label22.Location = new System.Drawing.Point(41, 92);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(16, 16);
            this.label22.TabIndex = 0;
            this.label22.Tag = "Value[3],Value2[3],4,3";
            this.label22.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.Control;
            this.label21.Font = new System.Drawing.Font("宋体", 12F);
            this.label21.Location = new System.Drawing.Point(41, 71);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(16, 16);
            this.label21.TabIndex = 0;
            this.label21.Tag = "Value[2],Value2[2],4,3";
            this.label21.Text = "0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.Control;
            this.label20.Font = new System.Drawing.Font("宋体", 12F);
            this.label20.Location = new System.Drawing.Point(41, 50);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(16, 16);
            this.label20.TabIndex = 0;
            this.label20.Tag = "Value[1],Value2[1],4,3";
            this.label20.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.Control;
            this.label19.Font = new System.Drawing.Font("宋体", 12F);
            this.label19.Location = new System.Drawing.Point(41, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(16, 16);
            this.label19.TabIndex = 0;
            this.label19.Tag = "Value[0],Value2[0],4,3";
            this.label19.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.Font = new System.Drawing.Font("宋体", 12F);
            this.label6.Location = new System.Drawing.Point(11, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "X:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.Control;
            this.label10.Font = new System.Drawing.Font("宋体", 12F);
            this.label10.Location = new System.Drawing.Point(11, 252);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 16);
            this.label10.TabIndex = 0;
            this.label10.Text = "第4轴:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("宋体", 12F);
            this.label3.Location = new System.Drawing.Point(11, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "N:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("宋体", 12F);
            this.label9.Location = new System.Drawing.Point(52, 164);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 16);
            this.label9.TabIndex = 0;
            this.label9.Text = "角度";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label16.Font = new System.Drawing.Font("宋体", 12F);
            this.label16.Location = new System.Drawing.Point(305, 5);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 16);
            this.label16.TabIndex = 0;
            this.label16.Text = "端口";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("宋体", 12F);
            this.label2.Location = new System.Drawing.Point(52, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "坐标";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Location = new System.Drawing.Point(148, 24);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(333, 296);
            this.pictureBox6.TabIndex = 1;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Location = new System.Drawing.Point(0, 183);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(148, 137);
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(0, 159);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(148, 25);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(0, 24);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(148, 136);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Location = new System.Drawing.Point(148, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(332, 25);
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(148, 25);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "代码";
            // 
            // CodeBox
            // 
            this.CodeBox.Location = new System.Drawing.Point(15, 29);
            this.CodeBox.Multiline = true;
            this.CodeBox.Name = "CodeBox";
            this.CodeBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.CodeBox.Size = new System.Drawing.Size(444, 237);
            this.CodeBox.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 272);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "关闭";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // UIPanel2
            // 
            this.UIPanel2.Controls.Add(this.label74);
            this.UIPanel2.Controls.Add(this.label73);
            this.UIPanel2.Controls.Add(this.label66);
            this.UIPanel2.Controls.Add(this.label65);
            this.UIPanel2.Controls.Add(this.label64);
            this.UIPanel2.Controls.Add(this.label63);
            this.UIPanel2.Controls.Add(this.label62);
            this.UIPanel2.Controls.Add(this.label76);
            this.UIPanel2.Controls.Add(this.label75);
            this.UIPanel2.Controls.Add(this.label72);
            this.UIPanel2.Controls.Add(this.label71);
            this.UIPanel2.Controls.Add(this.label70);
            this.UIPanel2.Controls.Add(this.label69);
            this.UIPanel2.Controls.Add(this.label68);
            this.UIPanel2.Controls.Add(this.label67);
            this.UIPanel2.Controls.Add(this.label61);
            this.UIPanel2.Controls.Add(this.label60);
            this.UIPanel2.Controls.Add(this.pictureBox38);
            this.UIPanel2.Controls.Add(this.pictureBox39);
            this.UIPanel2.Location = new System.Drawing.Point(0, 0);
            this.UIPanel2.Name = "UIPanel2";
            this.UIPanel2.Size = new System.Drawing.Size(480, 320);
            this.UIPanel2.TabIndex = 4;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.MidnightBlue;
            this.label74.Font = new System.Drawing.Font("宋体", 20F);
            this.label74.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label74.Location = new System.Drawing.Point(18, 270);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(204, 27);
            this.label74.TabIndex = 2;
            this.label74.Text = "运行速率(KHz):";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.MidnightBlue;
            this.label73.Font = new System.Drawing.Font("宋体", 20F);
            this.label73.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label73.Location = new System.Drawing.Point(18, 228);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(190, 27);
            this.label73.TabIndex = 2;
            this.label73.Text = "步进距离(mm):";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.MidnightBlue;
            this.label66.Font = new System.Drawing.Font("宋体", 24F);
            this.label66.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label66.Location = new System.Drawing.Point(278, 140);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(47, 33);
            this.label66.TabIndex = 2;
            this.label66.Text = "A:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.MidnightBlue;
            this.label65.Font = new System.Drawing.Font("宋体", 24F);
            this.label65.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label65.Location = new System.Drawing.Point(278, 97);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(47, 33);
            this.label65.TabIndex = 2;
            this.label65.Text = "O:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.MidnightBlue;
            this.label64.Font = new System.Drawing.Font("宋体", 24F);
            this.label64.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label64.Location = new System.Drawing.Point(278, 55);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(47, 33);
            this.label64.TabIndex = 2;
            this.label64.Text = "N:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.MidnightBlue;
            this.label63.Font = new System.Drawing.Font("宋体", 24F);
            this.label63.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label63.Location = new System.Drawing.Point(17, 140);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(47, 33);
            this.label63.TabIndex = 2;
            this.label63.Text = "Z:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.MidnightBlue;
            this.label62.Font = new System.Drawing.Font("宋体", 24F);
            this.label62.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label62.Location = new System.Drawing.Point(17, 98);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(47, 33);
            this.label62.TabIndex = 2;
            this.label62.Text = "Y:";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.MidnightBlue;
            this.label76.Font = new System.Drawing.Font("宋体", 24F);
            this.label76.ForeColor = System.Drawing.SystemColors.Control;
            this.label76.Location = new System.Drawing.Point(228, 268);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(31, 33);
            this.label76.TabIndex = 2;
            this.label76.Tag = "Value[7],Value2[7],4,0";
            this.label76.Text = "0";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.MidnightBlue;
            this.label75.Font = new System.Drawing.Font("宋体", 24F);
            this.label75.ForeColor = System.Drawing.SystemColors.Control;
            this.label75.Location = new System.Drawing.Point(214, 226);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(31, 33);
            this.label75.TabIndex = 2;
            this.label75.Tag = "Value[6],Value2[6],4,2";
            this.label75.Text = "0";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.MidnightBlue;
            this.label72.Font = new System.Drawing.Font("宋体", 24F);
            this.label72.ForeColor = System.Drawing.SystemColors.Control;
            this.label72.Location = new System.Drawing.Point(331, 140);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(31, 33);
            this.label72.TabIndex = 5;
            this.label72.Tag = "Value[x],Value2[x],3,2";
            this.label72.Text = "0";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.MidnightBlue;
            this.label71.Font = new System.Drawing.Font("宋体", 24F);
            this.label71.ForeColor = System.Drawing.SystemColors.Control;
            this.label71.Location = new System.Drawing.Point(331, 98);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(31, 33);
            this.label71.TabIndex = 4;
            this.label71.Tag = "Value[x],Value2[x],3,2";
            this.label71.Text = "0";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.MidnightBlue;
            this.label70.Font = new System.Drawing.Font("宋体", 24F);
            this.label70.ForeColor = System.Drawing.SystemColors.Control;
            this.label70.Location = new System.Drawing.Point(331, 55);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(31, 33);
            this.label70.TabIndex = 3;
            this.label70.Tag = "Value[x],Value2[x],3,2";
            this.label70.Text = "0";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.MidnightBlue;
            this.label69.Font = new System.Drawing.Font("宋体", 24F);
            this.label69.ForeColor = System.Drawing.SystemColors.Control;
            this.label69.Location = new System.Drawing.Point(70, 140);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(31, 33);
            this.label69.TabIndex = 2;
            this.label69.Tag = "Value[x],Value2[x],4,3";
            this.label69.Text = "0";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.MidnightBlue;
            this.label68.Font = new System.Drawing.Font("宋体", 24F);
            this.label68.ForeColor = System.Drawing.SystemColors.Control;
            this.label68.Location = new System.Drawing.Point(70, 97);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(31, 33);
            this.label68.TabIndex = 1;
            this.label68.Tag = "Value[x],Value2[x],4,3";
            this.label68.Text = "0";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.MidnightBlue;
            this.label67.Font = new System.Drawing.Font("宋体", 24F);
            this.label67.ForeColor = System.Drawing.SystemColors.Control;
            this.label67.Location = new System.Drawing.Point(70, 56);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(31, 33);
            this.label67.TabIndex = 0;
            this.label67.Tag = "Value[x],Value2[x],4,3";
            this.label67.Text = "0";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.MidnightBlue;
            this.label61.Font = new System.Drawing.Font("宋体", 24F);
            this.label61.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label61.Location = new System.Drawing.Point(17, 56);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(47, 33);
            this.label61.TabIndex = 2;
            this.label61.Text = "X:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label60.Font = new System.Drawing.Font("宋体", 26F);
            this.label60.Location = new System.Drawing.Point(195, 4);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(85, 35);
            this.label60.TabIndex = 0;
            this.label60.Text = "坐标";
            // 
            // pictureBox38
            // 
            this.pictureBox38.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox38.Location = new System.Drawing.Point(0, 0);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(480, 43);
            this.pictureBox38.TabIndex = 1;
            this.pictureBox38.TabStop = false;
            // 
            // pictureBox39
            // 
            this.pictureBox39.BackColor = System.Drawing.Color.MidnightBlue;
            this.pictureBox39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox39.Location = new System.Drawing.Point(0, 43);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(480, 277);
            this.pictureBox39.TabIndex = 1;
            this.pictureBox39.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(465, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(490, 349);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.UIPanel);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(482, 323);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.UIPanel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(482, 323);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.UIPanel3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(482, 323);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // UIPanel3
            // 
            this.UIPanel3.BackColor = System.Drawing.SystemColors.Control;
            this.UIPanel3.Controls.Add(this.label94);
            this.UIPanel3.Controls.Add(this.label95);
            this.UIPanel3.Controls.Add(this.label92);
            this.UIPanel3.Controls.Add(this.label93);
            this.UIPanel3.Controls.Add(this.label91);
            this.UIPanel3.Controls.Add(this.label89);
            this.UIPanel3.Controls.Add(this.label87);
            this.UIPanel3.Controls.Add(this.label85);
            this.UIPanel3.Controls.Add(this.label83);
            this.UIPanel3.Controls.Add(this.label80);
            this.UIPanel3.Controls.Add(this.label90);
            this.UIPanel3.Controls.Add(this.label88);
            this.UIPanel3.Controls.Add(this.label86);
            this.UIPanel3.Controls.Add(this.label84);
            this.UIPanel3.Controls.Add(this.label82);
            this.UIPanel3.Controls.Add(this.label81);
            this.UIPanel3.Controls.Add(this.label79);
            this.UIPanel3.Controls.Add(this.pictureBox78);
            this.UIPanel3.Controls.Add(this.pictureBox77);
            this.UIPanel3.Controls.Add(this.pictureBox76);
            this.UIPanel3.Controls.Add(this.pictureBox75);
            this.UIPanel3.Controls.Add(this.pictureBox40);
            this.UIPanel3.Controls.Add(this.pictureBox41);
            this.UIPanel3.Location = new System.Drawing.Point(0, 0);
            this.UIPanel3.Name = "UIPanel3";
            this.UIPanel3.Size = new System.Drawing.Size(480, 320);
            this.UIPanel3.TabIndex = 0;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.BackColor = System.Drawing.Color.MediumBlue;
            this.label94.Font = new System.Drawing.Font("宋体", 20F);
            this.label94.ForeColor = System.Drawing.Color.White;
            this.label94.Location = new System.Drawing.Point(335, 45);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(120, 27);
            this.label94.TabIndex = 9;
            this.label94.Text = "运行速率";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.BackColor = System.Drawing.Color.MediumBlue;
            this.label95.Font = new System.Drawing.Font("宋体", 24F);
            this.label95.ForeColor = System.Drawing.Color.White;
            this.label95.Location = new System.Drawing.Point(324, 105);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(31, 33);
            this.label95.TabIndex = 10;
            this.label95.Tag = "Value[7],Value2[7],4,0";
            this.label95.Text = "0";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.BackColor = System.Drawing.Color.MediumBlue;
            this.label92.Font = new System.Drawing.Font("宋体", 20F);
            this.label92.ForeColor = System.Drawing.Color.White;
            this.label92.Location = new System.Drawing.Point(335, 188);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(120, 27);
            this.label92.TabIndex = 7;
            this.label92.Text = "步进角度";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.BackColor = System.Drawing.Color.MediumBlue;
            this.label93.Font = new System.Drawing.Font("宋体", 24F);
            this.label93.ForeColor = System.Drawing.Color.White;
            this.label93.Location = new System.Drawing.Point(324, 257);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(31, 33);
            this.label93.TabIndex = 8;
            this.label93.Tag = "Value[6],Value2[6],4,2";
            this.label93.Text = "0";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.BackColor = System.Drawing.Color.MidnightBlue;
            this.label91.Font = new System.Drawing.Font("宋体", 24F);
            this.label91.ForeColor = System.Drawing.SystemColors.Control;
            this.label91.Location = new System.Drawing.Point(85, 257);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(31, 33);
            this.label91.TabIndex = 5;
            this.label91.Tag = "Value[x],Value2[x],4,3";
            this.label91.Text = "0";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.Color.MidnightBlue;
            this.label89.Font = new System.Drawing.Font("宋体", 24F);
            this.label89.ForeColor = System.Drawing.SystemColors.Control;
            this.label89.Location = new System.Drawing.Point(85, 215);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(31, 33);
            this.label89.TabIndex = 4;
            this.label89.Tag = "Value[x],Value2[x],4,3";
            this.label89.Text = "0";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.BackColor = System.Drawing.Color.MidnightBlue;
            this.label87.Font = new System.Drawing.Font("宋体", 24F);
            this.label87.ForeColor = System.Drawing.SystemColors.Control;
            this.label87.Location = new System.Drawing.Point(85, 173);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(31, 33);
            this.label87.TabIndex = 3;
            this.label87.Tag = "Value[x],Value2[x],4,3";
            this.label87.Text = "0";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.BackColor = System.Drawing.Color.MidnightBlue;
            this.label85.Font = new System.Drawing.Font("宋体", 24F);
            this.label85.ForeColor = System.Drawing.SystemColors.Control;
            this.label85.Location = new System.Drawing.Point(85, 135);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(31, 33);
            this.label85.TabIndex = 2;
            this.label85.Tag = "Value[x],Value2[x],4,3";
            this.label85.Text = "0";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.BackColor = System.Drawing.Color.MidnightBlue;
            this.label83.Font = new System.Drawing.Font("宋体", 24F);
            this.label83.ForeColor = System.Drawing.SystemColors.Control;
            this.label83.Location = new System.Drawing.Point(85, 93);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(31, 33);
            this.label83.TabIndex = 1;
            this.label83.Tag = "Value[x],Value2[x],4,3";
            this.label83.Text = "0";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.BackColor = System.Drawing.Color.MidnightBlue;
            this.label80.Font = new System.Drawing.Font("宋体", 24F);
            this.label80.ForeColor = System.Drawing.SystemColors.Control;
            this.label80.Location = new System.Drawing.Point(85, 51);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(31, 33);
            this.label80.TabIndex = 0;
            this.label80.Tag = "Value[x],Value2[x],4,3";
            this.label80.Text = "0";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.BackColor = System.Drawing.Color.MidnightBlue;
            this.label90.Font = new System.Drawing.Font("宋体", 24F);
            this.label90.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label90.Location = new System.Drawing.Point(12, 257);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(79, 33);
            this.label90.TabIndex = 6;
            this.label90.Text = "轴6:";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.BackColor = System.Drawing.Color.MidnightBlue;
            this.label88.Font = new System.Drawing.Font("宋体", 24F);
            this.label88.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label88.Location = new System.Drawing.Point(12, 215);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(79, 33);
            this.label88.TabIndex = 6;
            this.label88.Text = "轴5:";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.BackColor = System.Drawing.Color.MidnightBlue;
            this.label86.Font = new System.Drawing.Font("宋体", 24F);
            this.label86.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label86.Location = new System.Drawing.Point(12, 173);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(79, 33);
            this.label86.TabIndex = 6;
            this.label86.Text = "轴4:";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.BackColor = System.Drawing.Color.MidnightBlue;
            this.label84.Font = new System.Drawing.Font("宋体", 24F);
            this.label84.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label84.Location = new System.Drawing.Point(12, 135);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(79, 33);
            this.label84.TabIndex = 6;
            this.label84.Text = "轴3:";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.BackColor = System.Drawing.Color.MidnightBlue;
            this.label82.Font = new System.Drawing.Font("宋体", 24F);
            this.label82.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label82.Location = new System.Drawing.Point(12, 93);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(79, 33);
            this.label82.TabIndex = 6;
            this.label82.Text = "轴2:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.BackColor = System.Drawing.Color.MidnightBlue;
            this.label81.Font = new System.Drawing.Font("宋体", 24F);
            this.label81.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label81.Location = new System.Drawing.Point(12, 51);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(79, 33);
            this.label81.TabIndex = 6;
            this.label81.Text = "轴1:";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label79.Font = new System.Drawing.Font("宋体", 26F);
            this.label79.Location = new System.Drawing.Point(195, 4);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(85, 35);
            this.label79.TabIndex = 2;
            this.label79.Text = "角度";
            // 
            // pictureBox40
            // 
            this.pictureBox40.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox40.Location = new System.Drawing.Point(0, 0);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(480, 43);
            this.pictureBox40.TabIndex = 3;
            this.pictureBox40.TabStop = false;
            // 
            // pictureBox41
            // 
            this.pictureBox41.BackColor = System.Drawing.Color.MidnightBlue;
            this.pictureBox41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox41.Location = new System.Drawing.Point(0, 43);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(480, 277);
            this.pictureBox41.TabIndex = 4;
            this.pictureBox41.TabStop = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.UIPanel4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(482, 323);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // UIPanel4
            // 
            this.UIPanel4.BackColor = System.Drawing.SystemColors.Control;
            this.UIPanel4.Controls.Add(this.label77);
            this.UIPanel4.Controls.Add(this.label128);
            this.UIPanel4.Controls.Add(this.label78);
            this.UIPanel4.Controls.Add(this.label127);
            this.UIPanel4.Controls.Add(this.label104);
            this.UIPanel4.Controls.Add(this.label105);
            this.UIPanel4.Controls.Add(this.label106);
            this.UIPanel4.Controls.Add(this.label107);
            this.UIPanel4.Controls.Add(this.label108);
            this.UIPanel4.Controls.Add(this.label109);
            this.UIPanel4.Controls.Add(this.label110);
            this.UIPanel4.Controls.Add(this.label111);
            this.UIPanel4.Controls.Add(this.label113);
            this.UIPanel4.Controls.Add(this.label114);
            this.UIPanel4.Controls.Add(this.label129);
            this.UIPanel4.Controls.Add(this.label115);
            this.UIPanel4.Controls.Add(this.label116);
            this.UIPanel4.Controls.Add(this.label117);
            this.UIPanel4.Controls.Add(this.pictureBox52);
            this.UIPanel4.Controls.Add(this.pictureBox53);
            this.UIPanel4.Controls.Add(this.label118);
            this.UIPanel4.Controls.Add(this.label119);
            this.UIPanel4.Controls.Add(this.label120);
            this.UIPanel4.Controls.Add(this.label121);
            this.UIPanel4.Controls.Add(this.label122);
            this.UIPanel4.Controls.Add(this.label123);
            this.UIPanel4.Controls.Add(this.pictureBox54);
            this.UIPanel4.Controls.Add(this.pictureBox55);
            this.UIPanel4.Controls.Add(this.pictureBox56);
            this.UIPanel4.Controls.Add(this.pictureBox57);
            this.UIPanel4.Controls.Add(this.pictureBox58);
            this.UIPanel4.Controls.Add(this.pictureBox59);
            this.UIPanel4.Controls.Add(this.label124);
            this.UIPanel4.Controls.Add(this.label125);
            this.UIPanel4.Controls.Add(this.label126);
            this.UIPanel4.Controls.Add(this.pictureBox60);
            this.UIPanel4.Controls.Add(this.pictureBox61);
            this.UIPanel4.Controls.Add(this.pictureBox62);
            this.UIPanel4.Controls.Add(this.pictureBox63);
            this.UIPanel4.Controls.Add(this.pictureBox64);
            this.UIPanel4.Controls.Add(this.pictureBox65);
            this.UIPanel4.Controls.Add(this.pictureBox66);
            this.UIPanel4.Controls.Add(this.pictureBox67);
            this.UIPanel4.Controls.Add(this.pictureBox68);
            this.UIPanel4.Controls.Add(this.pictureBox69);
            this.UIPanel4.Controls.Add(this.pictureBox70);
            this.UIPanel4.Controls.Add(this.pictureBox71);
            this.UIPanel4.Controls.Add(this.pictureBox72);
            this.UIPanel4.Controls.Add(this.pictureBox73);
            this.UIPanel4.Controls.Add(this.pictureBox74);
            this.UIPanel4.Controls.Add(this.label96);
            this.UIPanel4.Controls.Add(this.label97);
            this.UIPanel4.Controls.Add(this.label98);
            this.UIPanel4.Controls.Add(this.label99);
            this.UIPanel4.Controls.Add(this.label100);
            this.UIPanel4.Controls.Add(this.pictureBox44);
            this.UIPanel4.Controls.Add(this.label101);
            this.UIPanel4.Controls.Add(this.label102);
            this.UIPanel4.Controls.Add(this.pictureBox45);
            this.UIPanel4.Controls.Add(this.pictureBox46);
            this.UIPanel4.Controls.Add(this.label103);
            this.UIPanel4.Controls.Add(this.pictureBox47);
            this.UIPanel4.Controls.Add(this.pictureBox48);
            this.UIPanel4.Controls.Add(this.pictureBox49);
            this.UIPanel4.Controls.Add(this.pictureBox50);
            this.UIPanel4.Controls.Add(this.pictureBox51);
            this.UIPanel4.Controls.Add(this.label112);
            this.UIPanel4.Controls.Add(this.pictureBox42);
            this.UIPanel4.Controls.Add(this.pictureBox81);
            this.UIPanel4.Controls.Add(this.pictureBox79);
            this.UIPanel4.Controls.Add(this.pictureBox80);
            this.UIPanel4.Controls.Add(this.pictureBox43);
            this.UIPanel4.Location = new System.Drawing.Point(0, 0);
            this.UIPanel4.Name = "UIPanel4";
            this.UIPanel4.Size = new System.Drawing.Size(480, 320);
            this.UIPanel4.TabIndex = 1;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.BackColor = System.Drawing.Color.MidnightBlue;
            this.label128.Font = new System.Drawing.Font("宋体", 20F);
            this.label128.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label128.Location = new System.Drawing.Point(8, 56);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(39, 27);
            this.label128.TabIndex = 66;
            this.label128.Text = "输";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.BackColor = System.Drawing.Color.MidnightBlue;
            this.label127.Font = new System.Drawing.Font("宋体", 20F);
            this.label127.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label127.Location = new System.Drawing.Point(8, 174);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(39, 27);
            this.label127.TabIndex = 66;
            this.label127.Text = "输";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.BackColor = System.Drawing.Color.MidnightBlue;
            this.label104.Font = new System.Drawing.Font("宋体", 12F);
            this.label104.ForeColor = System.Drawing.SystemColors.Control;
            this.label104.Location = new System.Drawing.Point(363, 228);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(32, 16);
            this.label104.TabIndex = 65;
            this.label104.Text = "I16";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.BackColor = System.Drawing.Color.MidnightBlue;
            this.label105.Font = new System.Drawing.Font("宋体", 12F);
            this.label105.ForeColor = System.Drawing.SystemColors.Control;
            this.label105.Location = new System.Drawing.Point(367, 174);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(24, 16);
            this.label105.TabIndex = 45;
            this.label105.Text = "I8";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.BackColor = System.Drawing.Color.MidnightBlue;
            this.label106.Font = new System.Drawing.Font("宋体", 12F);
            this.label106.ForeColor = System.Drawing.SystemColors.Control;
            this.label106.Location = new System.Drawing.Point(211, 282);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(32, 16);
            this.label106.TabIndex = 46;
            this.label106.Text = "I20";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.BackColor = System.Drawing.Color.MidnightBlue;
            this.label107.Font = new System.Drawing.Font("宋体", 12F);
            this.label107.ForeColor = System.Drawing.SystemColors.Control;
            this.label107.Location = new System.Drawing.Point(211, 228);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(32, 16);
            this.label107.TabIndex = 47;
            this.label107.Text = "I12";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.BackColor = System.Drawing.Color.MidnightBlue;
            this.label108.Font = new System.Drawing.Font("宋体", 12F);
            this.label108.ForeColor = System.Drawing.SystemColors.Control;
            this.label108.Location = new System.Drawing.Point(215, 174);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(24, 16);
            this.label108.TabIndex = 48;
            this.label108.Text = "I4";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.BackColor = System.Drawing.Color.MidnightBlue;
            this.label109.Font = new System.Drawing.Font("宋体", 12F);
            this.label109.ForeColor = System.Drawing.SystemColors.Control;
            this.label109.Location = new System.Drawing.Point(324, 228);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(32, 16);
            this.label109.TabIndex = 49;
            this.label109.Text = "I15";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.BackColor = System.Drawing.Color.MidnightBlue;
            this.label110.Font = new System.Drawing.Font("宋体", 12F);
            this.label110.ForeColor = System.Drawing.SystemColors.Control;
            this.label110.Location = new System.Drawing.Point(329, 174);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(24, 16);
            this.label110.TabIndex = 50;
            this.label110.Text = "I7";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.BackColor = System.Drawing.Color.MidnightBlue;
            this.label111.Font = new System.Drawing.Font("宋体", 12F);
            this.label111.ForeColor = System.Drawing.SystemColors.Control;
            this.label111.Location = new System.Drawing.Point(173, 282);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(32, 16);
            this.label111.TabIndex = 51;
            this.label111.Text = "I19";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.BackColor = System.Drawing.Color.MidnightBlue;
            this.label113.Font = new System.Drawing.Font("宋体", 12F);
            this.label113.ForeColor = System.Drawing.SystemColors.Control;
            this.label113.Location = new System.Drawing.Point(173, 228);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(32, 16);
            this.label113.TabIndex = 52;
            this.label113.Text = "I11";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.BackColor = System.Drawing.Color.MidnightBlue;
            this.label114.Font = new System.Drawing.Font("宋体", 12F);
            this.label114.ForeColor = System.Drawing.SystemColors.Control;
            this.label114.Location = new System.Drawing.Point(177, 174);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(24, 16);
            this.label114.TabIndex = 53;
            this.label114.Text = "I3";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.BackColor = System.Drawing.Color.MidnightBlue;
            this.label129.Font = new System.Drawing.Font("宋体", 12F);
            this.label129.ForeColor = System.Drawing.SystemColors.Control;
            this.label129.Location = new System.Drawing.Point(325, 282);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(32, 16);
            this.label129.TabIndex = 64;
            this.label129.Text = "I23";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.BackColor = System.Drawing.Color.MidnightBlue;
            this.label115.Font = new System.Drawing.Font("宋体", 12F);
            this.label115.ForeColor = System.Drawing.SystemColors.Control;
            this.label115.Location = new System.Drawing.Point(287, 282);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(32, 16);
            this.label115.TabIndex = 64;
            this.label115.Text = "I22";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.BackColor = System.Drawing.Color.MidnightBlue;
            this.label116.Font = new System.Drawing.Font("宋体", 12F);
            this.label116.ForeColor = System.Drawing.SystemColors.Control;
            this.label116.Location = new System.Drawing.Point(286, 228);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(32, 16);
            this.label116.TabIndex = 54;
            this.label116.Text = "I14";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.BackColor = System.Drawing.Color.MidnightBlue;
            this.label117.Font = new System.Drawing.Font("宋体", 12F);
            this.label117.ForeColor = System.Drawing.SystemColors.Control;
            this.label117.Location = new System.Drawing.Point(291, 174);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(24, 16);
            this.label117.TabIndex = 56;
            this.label117.Text = "I6";
            // 
            // pictureBox52
            // 
            this.pictureBox52.BackColor = System.Drawing.Color.Red;
            this.pictureBox52.Location = new System.Drawing.Point(360, 193);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(32, 32);
            this.pictureBox52.TabIndex = 43;
            this.pictureBox52.TabStop = false;
            this.pictureBox52.Tag = "Value&BIT15";
            // 
            // pictureBox53
            // 
            this.pictureBox53.BackColor = System.Drawing.Color.Red;
            this.pictureBox53.Location = new System.Drawing.Point(360, 139);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(32, 32);
            this.pictureBox53.TabIndex = 42;
            this.pictureBox53.TabStop = false;
            this.pictureBox53.Tag = "Value&BIT7";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.BackColor = System.Drawing.Color.MidnightBlue;
            this.label118.Font = new System.Drawing.Font("宋体", 12F);
            this.label118.ForeColor = System.Drawing.SystemColors.Control;
            this.label118.Location = new System.Drawing.Point(135, 282);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(32, 16);
            this.label118.TabIndex = 60;
            this.label118.Text = "I18";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.BackColor = System.Drawing.Color.MidnightBlue;
            this.label119.Font = new System.Drawing.Font("宋体", 12F);
            this.label119.ForeColor = System.Drawing.SystemColors.Control;
            this.label119.Location = new System.Drawing.Point(134, 228);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(32, 16);
            this.label119.TabIndex = 61;
            this.label119.Text = "I10";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.BackColor = System.Drawing.Color.MidnightBlue;
            this.label120.Font = new System.Drawing.Font("宋体", 12F);
            this.label120.ForeColor = System.Drawing.SystemColors.Control;
            this.label120.Location = new System.Drawing.Point(139, 174);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(24, 16);
            this.label120.TabIndex = 62;
            this.label120.Text = "I2";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.BackColor = System.Drawing.Color.MidnightBlue;
            this.label121.Font = new System.Drawing.Font("宋体", 12F);
            this.label121.ForeColor = System.Drawing.SystemColors.Control;
            this.label121.Location = new System.Drawing.Point(249, 282);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(32, 16);
            this.label121.TabIndex = 63;
            this.label121.Text = "I21";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.BackColor = System.Drawing.Color.MidnightBlue;
            this.label122.Font = new System.Drawing.Font("宋体", 12F);
            this.label122.ForeColor = System.Drawing.SystemColors.Control;
            this.label122.Location = new System.Drawing.Point(248, 228);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(32, 16);
            this.label122.TabIndex = 44;
            this.label122.Text = "I13";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.BackColor = System.Drawing.Color.MidnightBlue;
            this.label123.Font = new System.Drawing.Font("宋体", 12F);
            this.label123.ForeColor = System.Drawing.SystemColors.Control;
            this.label123.Location = new System.Drawing.Point(253, 174);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(24, 16);
            this.label123.TabIndex = 55;
            this.label123.Text = "I5";
            // 
            // pictureBox54
            // 
            this.pictureBox54.BackColor = System.Drawing.Color.Red;
            this.pictureBox54.Location = new System.Drawing.Point(208, 247);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(32, 32);
            this.pictureBox54.TabIndex = 40;
            this.pictureBox54.TabStop = false;
            this.pictureBox54.Tag = "Value&BIT19";
            // 
            // pictureBox55
            // 
            this.pictureBox55.BackColor = System.Drawing.Color.Red;
            this.pictureBox55.Location = new System.Drawing.Point(208, 193);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(32, 32);
            this.pictureBox55.TabIndex = 21;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.Tag = "Value&BIT11";
            // 
            // pictureBox56
            // 
            this.pictureBox56.BackColor = System.Drawing.Color.Red;
            this.pictureBox56.Location = new System.Drawing.Point(208, 139);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(32, 32);
            this.pictureBox56.TabIndex = 22;
            this.pictureBox56.TabStop = false;
            this.pictureBox56.Tag = "Value&BIT3";
            // 
            // pictureBox57
            // 
            this.pictureBox57.BackColor = System.Drawing.Color.Lime;
            this.pictureBox57.Location = new System.Drawing.Point(322, 247);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(32, 32);
            this.pictureBox57.TabIndex = 23;
            this.pictureBox57.TabStop = false;
            this.pictureBox57.Tag = "Value&BIT22";
            // 
            // pictureBox58
            // 
            this.pictureBox58.BackColor = System.Drawing.Color.Lime;
            this.pictureBox58.Location = new System.Drawing.Point(322, 193);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(32, 32);
            this.pictureBox58.TabIndex = 24;
            this.pictureBox58.TabStop = false;
            this.pictureBox58.Tag = "Value&BIT14";
            // 
            // pictureBox59
            // 
            this.pictureBox59.BackColor = System.Drawing.Color.Lime;
            this.pictureBox59.Location = new System.Drawing.Point(322, 139);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(32, 32);
            this.pictureBox59.TabIndex = 25;
            this.pictureBox59.TabStop = false;
            this.pictureBox59.Tag = "Value&BIT6";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.BackColor = System.Drawing.Color.MidnightBlue;
            this.label124.Font = new System.Drawing.Font("宋体", 12F);
            this.label124.ForeColor = System.Drawing.SystemColors.Control;
            this.label124.Location = new System.Drawing.Point(97, 282);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(32, 16);
            this.label124.TabIndex = 59;
            this.label124.Text = "I17";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.BackColor = System.Drawing.Color.MidnightBlue;
            this.label125.Font = new System.Drawing.Font("宋体", 12F);
            this.label125.ForeColor = System.Drawing.SystemColors.Control;
            this.label125.Location = new System.Drawing.Point(100, 228);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(24, 16);
            this.label125.TabIndex = 58;
            this.label125.Text = "I9";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.BackColor = System.Drawing.Color.MidnightBlue;
            this.label126.Font = new System.Drawing.Font("宋体", 12F);
            this.label126.ForeColor = System.Drawing.SystemColors.Control;
            this.label126.Location = new System.Drawing.Point(101, 174);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(24, 16);
            this.label126.TabIndex = 57;
            this.label126.Text = "I1";
            // 
            // pictureBox60
            // 
            this.pictureBox60.BackColor = System.Drawing.Color.Red;
            this.pictureBox60.Location = new System.Drawing.Point(284, 247);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(32, 32);
            this.pictureBox60.TabIndex = 26;
            this.pictureBox60.TabStop = false;
            this.pictureBox60.Tag = "Value&BIT21";
            // 
            // pictureBox61
            // 
            this.pictureBox61.BackColor = System.Drawing.Color.Red;
            this.pictureBox61.Location = new System.Drawing.Point(284, 193);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(32, 32);
            this.pictureBox61.TabIndex = 27;
            this.pictureBox61.TabStop = false;
            this.pictureBox61.Tag = "Value&BIT13";
            // 
            // pictureBox62
            // 
            this.pictureBox62.BackColor = System.Drawing.Color.Red;
            this.pictureBox62.Location = new System.Drawing.Point(284, 139);
            this.pictureBox62.Name = "pictureBox62";
            this.pictureBox62.Size = new System.Drawing.Size(32, 32);
            this.pictureBox62.TabIndex = 28;
            this.pictureBox62.TabStop = false;
            this.pictureBox62.Tag = "Value&BIT5";
            // 
            // pictureBox63
            // 
            this.pictureBox63.BackColor = System.Drawing.Color.Lime;
            this.pictureBox63.Location = new System.Drawing.Point(170, 247);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(32, 32);
            this.pictureBox63.TabIndex = 29;
            this.pictureBox63.TabStop = false;
            this.pictureBox63.Tag = "Value&BIT18";
            // 
            // pictureBox64
            // 
            this.pictureBox64.BackColor = System.Drawing.Color.Lime;
            this.pictureBox64.Location = new System.Drawing.Point(170, 193);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(32, 32);
            this.pictureBox64.TabIndex = 30;
            this.pictureBox64.TabStop = false;
            this.pictureBox64.Tag = "Value&BIT10";
            // 
            // pictureBox65
            // 
            this.pictureBox65.BackColor = System.Drawing.Color.Lime;
            this.pictureBox65.Location = new System.Drawing.Point(170, 139);
            this.pictureBox65.Name = "pictureBox65";
            this.pictureBox65.Size = new System.Drawing.Size(32, 32);
            this.pictureBox65.TabIndex = 31;
            this.pictureBox65.TabStop = false;
            this.pictureBox65.Tag = "Value&BIT2";
            // 
            // pictureBox66
            // 
            this.pictureBox66.BackColor = System.Drawing.Color.Lime;
            this.pictureBox66.Location = new System.Drawing.Point(246, 247);
            this.pictureBox66.Name = "pictureBox66";
            this.pictureBox66.Size = new System.Drawing.Size(32, 32);
            this.pictureBox66.TabIndex = 32;
            this.pictureBox66.TabStop = false;
            this.pictureBox66.Tag = "Value&BIT20";
            // 
            // pictureBox67
            // 
            this.pictureBox67.BackColor = System.Drawing.Color.Red;
            this.pictureBox67.Location = new System.Drawing.Point(132, 247);
            this.pictureBox67.Name = "pictureBox67";
            this.pictureBox67.Size = new System.Drawing.Size(32, 32);
            this.pictureBox67.TabIndex = 33;
            this.pictureBox67.TabStop = false;
            this.pictureBox67.Tag = "Value&BIT17";
            // 
            // pictureBox68
            // 
            this.pictureBox68.BackColor = System.Drawing.Color.Lime;
            this.pictureBox68.Location = new System.Drawing.Point(246, 193);
            this.pictureBox68.Name = "pictureBox68";
            this.pictureBox68.Size = new System.Drawing.Size(32, 32);
            this.pictureBox68.TabIndex = 34;
            this.pictureBox68.TabStop = false;
            this.pictureBox68.Tag = "Value&BIT12";
            // 
            // pictureBox69
            // 
            this.pictureBox69.BackColor = System.Drawing.Color.Red;
            this.pictureBox69.Location = new System.Drawing.Point(132, 193);
            this.pictureBox69.Name = "pictureBox69";
            this.pictureBox69.Size = new System.Drawing.Size(32, 32);
            this.pictureBox69.TabIndex = 35;
            this.pictureBox69.TabStop = false;
            this.pictureBox69.Tag = "Value&BIT9";
            // 
            // pictureBox70
            // 
            this.pictureBox70.BackColor = System.Drawing.Color.Lime;
            this.pictureBox70.Location = new System.Drawing.Point(246, 139);
            this.pictureBox70.Name = "pictureBox70";
            this.pictureBox70.Size = new System.Drawing.Size(32, 32);
            this.pictureBox70.TabIndex = 36;
            this.pictureBox70.TabStop = false;
            this.pictureBox70.Tag = "Value&BIT4";
            // 
            // pictureBox71
            // 
            this.pictureBox71.BackColor = System.Drawing.Color.Lime;
            this.pictureBox71.Location = new System.Drawing.Point(94, 247);
            this.pictureBox71.Name = "pictureBox71";
            this.pictureBox71.Size = new System.Drawing.Size(32, 32);
            this.pictureBox71.TabIndex = 37;
            this.pictureBox71.TabStop = false;
            this.pictureBox71.Tag = "Value&BIT16";
            // 
            // pictureBox72
            // 
            this.pictureBox72.BackColor = System.Drawing.Color.Red;
            this.pictureBox72.Location = new System.Drawing.Point(132, 139);
            this.pictureBox72.Name = "pictureBox72";
            this.pictureBox72.Size = new System.Drawing.Size(32, 32);
            this.pictureBox72.TabIndex = 38;
            this.pictureBox72.TabStop = false;
            this.pictureBox72.Tag = "Value&BIT1";
            // 
            // pictureBox73
            // 
            this.pictureBox73.BackColor = System.Drawing.Color.Lime;
            this.pictureBox73.Location = new System.Drawing.Point(94, 193);
            this.pictureBox73.Name = "pictureBox73";
            this.pictureBox73.Size = new System.Drawing.Size(32, 32);
            this.pictureBox73.TabIndex = 39;
            this.pictureBox73.TabStop = false;
            this.pictureBox73.Tag = "Value&BIT8";
            // 
            // pictureBox74
            // 
            this.pictureBox74.BackColor = System.Drawing.Color.Lime;
            this.pictureBox74.Location = new System.Drawing.Point(94, 139);
            this.pictureBox74.Name = "pictureBox74";
            this.pictureBox74.Size = new System.Drawing.Size(32, 32);
            this.pictureBox74.TabIndex = 41;
            this.pictureBox74.TabStop = false;
            this.pictureBox74.Tag = "Value&BIT0";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.BackColor = System.Drawing.Color.MidnightBlue;
            this.label96.Font = new System.Drawing.Font("宋体", 12F);
            this.label96.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label96.Location = new System.Drawing.Point(367, 93);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(24, 16);
            this.label96.TabIndex = 13;
            this.label96.Text = "O8";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.BackColor = System.Drawing.Color.MidnightBlue;
            this.label97.Font = new System.Drawing.Font("宋体", 12F);
            this.label97.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label97.Location = new System.Drawing.Point(215, 93);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(24, 16);
            this.label97.TabIndex = 14;
            this.label97.Text = "O4";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.BackColor = System.Drawing.Color.MidnightBlue;
            this.label98.Font = new System.Drawing.Font("宋体", 12F);
            this.label98.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label98.Location = new System.Drawing.Point(329, 93);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(24, 16);
            this.label98.TabIndex = 15;
            this.label98.Text = "O7";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.BackColor = System.Drawing.Color.MidnightBlue;
            this.label99.Font = new System.Drawing.Font("宋体", 12F);
            this.label99.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label99.Location = new System.Drawing.Point(177, 93);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(24, 16);
            this.label99.TabIndex = 16;
            this.label99.Text = "O3";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.BackColor = System.Drawing.Color.MidnightBlue;
            this.label100.Font = new System.Drawing.Font("宋体", 12F);
            this.label100.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label100.Location = new System.Drawing.Point(291, 93);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(24, 16);
            this.label100.TabIndex = 17;
            this.label100.Text = "O6";
            // 
            // pictureBox44
            // 
            this.pictureBox44.BackColor = System.Drawing.Color.Red;
            this.pictureBox44.Location = new System.Drawing.Point(360, 58);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(32, 32);
            this.pictureBox44.TabIndex = 5;
            this.pictureBox44.TabStop = false;
            this.pictureBox44.Tag = "Value2&BIT7";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.BackColor = System.Drawing.Color.MidnightBlue;
            this.label101.Font = new System.Drawing.Font("宋体", 12F);
            this.label101.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label101.Location = new System.Drawing.Point(139, 93);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(24, 16);
            this.label101.TabIndex = 18;
            this.label101.Text = "O2";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.BackColor = System.Drawing.Color.MidnightBlue;
            this.label102.Font = new System.Drawing.Font("宋体", 12F);
            this.label102.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label102.Location = new System.Drawing.Point(253, 93);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(24, 16);
            this.label102.TabIndex = 19;
            this.label102.Text = "O5";
            // 
            // pictureBox45
            // 
            this.pictureBox45.BackColor = System.Drawing.Color.Red;
            this.pictureBox45.Location = new System.Drawing.Point(208, 58);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(32, 32);
            this.pictureBox45.TabIndex = 6;
            this.pictureBox45.TabStop = false;
            this.pictureBox45.Tag = "Value2&BIT3";
            // 
            // pictureBox46
            // 
            this.pictureBox46.BackColor = System.Drawing.Color.Lime;
            this.pictureBox46.Location = new System.Drawing.Point(322, 58);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(32, 32);
            this.pictureBox46.TabIndex = 7;
            this.pictureBox46.TabStop = false;
            this.pictureBox46.Tag = "Value2&BIT6";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.BackColor = System.Drawing.Color.MidnightBlue;
            this.label103.Font = new System.Drawing.Font("宋体", 12F);
            this.label103.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label103.Location = new System.Drawing.Point(101, 93);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(24, 16);
            this.label103.TabIndex = 20;
            this.label103.Text = "O1";
            // 
            // pictureBox47
            // 
            this.pictureBox47.BackColor = System.Drawing.Color.Red;
            this.pictureBox47.Location = new System.Drawing.Point(284, 58);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(32, 32);
            this.pictureBox47.TabIndex = 8;
            this.pictureBox47.TabStop = false;
            this.pictureBox47.Tag = "Value2&BIT5";
            // 
            // pictureBox48
            // 
            this.pictureBox48.BackColor = System.Drawing.Color.Lime;
            this.pictureBox48.Location = new System.Drawing.Point(170, 58);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(32, 32);
            this.pictureBox48.TabIndex = 9;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.Tag = "Value2&BIT2";
            // 
            // pictureBox49
            // 
            this.pictureBox49.BackColor = System.Drawing.Color.Lime;
            this.pictureBox49.Location = new System.Drawing.Point(246, 58);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(32, 32);
            this.pictureBox49.TabIndex = 10;
            this.pictureBox49.TabStop = false;
            this.pictureBox49.Tag = "Value2&BIT4";
            // 
            // pictureBox50
            // 
            this.pictureBox50.BackColor = System.Drawing.Color.Red;
            this.pictureBox50.Location = new System.Drawing.Point(132, 58);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(32, 32);
            this.pictureBox50.TabIndex = 11;
            this.pictureBox50.TabStop = false;
            this.pictureBox50.Tag = "Value2&BIT1";
            // 
            // pictureBox51
            // 
            this.pictureBox51.BackColor = System.Drawing.Color.Lime;
            this.pictureBox51.Location = new System.Drawing.Point(94, 58);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(32, 32);
            this.pictureBox51.TabIndex = 12;
            this.pictureBox51.TabStop = false;
            this.pictureBox51.Tag = "Value2&BIT0";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label112.Font = new System.Drawing.Font("宋体", 26F);
            this.label112.Location = new System.Drawing.Point(195, 4);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(85, 35);
            this.label112.TabIndex = 2;
            this.label112.Text = "端口";
            // 
            // pictureBox42
            // 
            this.pictureBox42.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox42.Location = new System.Drawing.Point(0, 0);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(480, 43);
            this.pictureBox42.TabIndex = 3;
            this.pictureBox42.TabStop = false;
            // 
            // pictureBox43
            // 
            this.pictureBox43.BackColor = System.Drawing.Color.MidnightBlue;
            this.pictureBox43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox43.Location = new System.Drawing.Point(0, 43);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(49, 77);
            this.pictureBox43.TabIndex = 4;
            this.pictureBox43.TabStop = false;
            // 
            // pictureBox75
            // 
            this.pictureBox75.BackColor = System.Drawing.Color.MediumBlue;
            this.pictureBox75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox75.Location = new System.Drawing.Point(289, 43);
            this.pictureBox75.Name = "pictureBox75";
            this.pictureBox75.Size = new System.Drawing.Size(191, 33);
            this.pictureBox75.TabIndex = 3;
            this.pictureBox75.TabStop = false;
            // 
            // pictureBox76
            // 
            this.pictureBox76.BackColor = System.Drawing.Color.MediumBlue;
            this.pictureBox76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox76.Location = new System.Drawing.Point(289, 76);
            this.pictureBox76.Name = "pictureBox76";
            this.pictureBox76.Size = new System.Drawing.Size(191, 109);
            this.pictureBox76.TabIndex = 3;
            this.pictureBox76.TabStop = false;
            // 
            // pictureBox77
            // 
            this.pictureBox77.BackColor = System.Drawing.Color.MediumBlue;
            this.pictureBox77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox77.Location = new System.Drawing.Point(289, 185);
            this.pictureBox77.Name = "pictureBox77";
            this.pictureBox77.Size = new System.Drawing.Size(191, 33);
            this.pictureBox77.TabIndex = 3;
            this.pictureBox77.TabStop = false;
            // 
            // pictureBox78
            // 
            this.pictureBox78.BackColor = System.Drawing.Color.MediumBlue;
            this.pictureBox78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox78.Location = new System.Drawing.Point(289, 218);
            this.pictureBox78.Name = "pictureBox78";
            this.pictureBox78.Size = new System.Drawing.Size(191, 102);
            this.pictureBox78.TabIndex = 3;
            this.pictureBox78.TabStop = false;
            // 
            // pictureBox79
            // 
            this.pictureBox79.BackColor = System.Drawing.Color.MidnightBlue;
            this.pictureBox79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox79.Location = new System.Drawing.Point(0, 120);
            this.pictureBox79.Name = "pictureBox79";
            this.pictureBox79.Size = new System.Drawing.Size(49, 200);
            this.pictureBox79.TabIndex = 4;
            this.pictureBox79.TabStop = false;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.MidnightBlue;
            this.label77.Font = new System.Drawing.Font("宋体", 20F);
            this.label77.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label77.Location = new System.Drawing.Point(8, 84);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(39, 27);
            this.label77.TabIndex = 66;
            this.label77.Text = "出";
            // 
            // pictureBox80
            // 
            this.pictureBox80.BackColor = System.Drawing.Color.MidnightBlue;
            this.pictureBox80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox80.Location = new System.Drawing.Point(49, 43);
            this.pictureBox80.Name = "pictureBox80";
            this.pictureBox80.Size = new System.Drawing.Size(430, 77);
            this.pictureBox80.TabIndex = 4;
            this.pictureBox80.TabStop = false;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.MidnightBlue;
            this.label78.Font = new System.Drawing.Font("宋体", 20F);
            this.label78.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label78.Location = new System.Drawing.Point(8, 242);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(39, 27);
            this.label78.TabIndex = 66;
            this.label78.Text = "入";
            // 
            // pictureBox81
            // 
            this.pictureBox81.BackColor = System.Drawing.Color.MidnightBlue;
            this.pictureBox81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox81.Location = new System.Drawing.Point(49, 120);
            this.pictureBox81.Name = "pictureBox81";
            this.pictureBox81.Size = new System.Drawing.Size(430, 200);
            this.pictureBox81.TabIndex = 4;
            this.pictureBox81.TabStop = false;
            // 
            // GCodeLoader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(997, 632);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.CodeBox);
            this.Controls.Add(this.label1);
            this.Name = "GCodeLoader";
            this.Text = "UIWindow";
            this.Load += new System.EventHandler(this.GCodeLoader_Load);
            this.UIPanel.ResumeLayout(false);
            this.UIPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.UIPanel2.ResumeLayout(false);
            this.UIPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.UIPanel3.ResumeLayout(false);
            this.UIPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.UIPanel4.ResumeLayout(false);
            this.UIPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel UIPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CodeBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Panel UIPanel2;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel UIPanel3;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel UIPanel4;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.PictureBox pictureBox62;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox65;
        private System.Windows.Forms.PictureBox pictureBox66;
        private System.Windows.Forms.PictureBox pictureBox67;
        private System.Windows.Forms.PictureBox pictureBox68;
        private System.Windows.Forms.PictureBox pictureBox69;
        private System.Windows.Forms.PictureBox pictureBox70;
        private System.Windows.Forms.PictureBox pictureBox71;
        private System.Windows.Forms.PictureBox pictureBox72;
        private System.Windows.Forms.PictureBox pictureBox73;
        private System.Windows.Forms.PictureBox pictureBox74;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.PictureBox pictureBox78;
        private System.Windows.Forms.PictureBox pictureBox77;
        private System.Windows.Forms.PictureBox pictureBox76;
        private System.Windows.Forms.PictureBox pictureBox75;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.PictureBox pictureBox81;
        private System.Windows.Forms.PictureBox pictureBox79;
        private System.Windows.Forms.PictureBox pictureBox80;
    }
}