﻿using KeyMove.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KControl
{
    class BuildCode
    {

        enum CodeBinData:int
        {
            RESTOUT = 0,
            OUTSIG = 1,
            INPUTSIG = 2,
            DELAY = 3,
            PWMCONFIG = 4,
            PWMOUT = 5,
            PWMSTOP = 6,
        }
        

        static public byte[] CodeToBytes(List<LogicRun.ModeObject> logic,byte[] headdata=null) 
        {
            ByteStream head = new ByteStream(logic.Count * 2+10);
            ByteStream data = new ByteStream(logic.Count*32);
            head.WriteWord(logic.Count);
            if (headdata != null)
            {
                head.WriteByte(headdata.Length);
                head.WriteBuff(headdata);
            }
            foreach(LogicRun.ModeObject obj in logic)
            {
                if(obj is LogicRun.SetOutput)
                {
                    head.WriteWord(data.Pos);
                    data.WriteByte((int)CodeBinData.OUTSIG);
                    data.WriteByte(((LogicRun.SetOutput)obj).len);
                    data.WriteBuff(((LogicRun.SetOutput)obj).outputbit);
                }
                else if(obj is LogicRun.CheckInput)
                {
                    head.WriteWord(data.Pos);
                    data.WriteByte((int)CodeBinData.INPUTSIG);
                    data.WriteByte(((LogicRun.CheckInput)obj).len);
                    data.WriteBuff(((LogicRun.CheckInput)obj).inputdata);
                    data.WriteBuff(((LogicRun.CheckInput)obj).enableinput);
                }
                else if(obj is LogicRun.Delay)
                {
                    head.WriteWord(data.Pos);
                    data.WriteByte((int)CodeBinData.DELAY);
                    data.WriteWord(((LogicRun.Delay)obj).time);
                }
                else if(obj is LogicRun.SetSpeed)
                {
                    head.WriteWord(data.Pos);
                    data.WriteByte((int)CodeBinData.PWMCONFIG);
                    data.WriteWord(((LogicRun.SetSpeed)obj).startspeed);
                    data.WriteWord(((LogicRun.SetSpeed)obj).addtime);
                    data.WriteDWord(((LogicRun.SetSpeed)obj).frequency);
                }
                else if(obj is LogicRun.G0)
                {
                    head.WriteWord(data.Pos);
                    data.WriteByte((int)CodeBinData.PWMOUT);
                    data.WriteByte(Axis6.MaxAxis);
                    int[] pls= Motor.AngleToPluse(((LogicRun.G0)obj).dest.angle);
                    for (int i = 0; i < Axis6.MaxAxis; i++)
                    {
                        data.WriteByte(i);
                        data.WriteDWord(pls[i]);
                    }
                }
            }
            byte[] a = head.toBytes();
            byte[] b = data.toBytes();
            ByteStream c = new ByteStream(a.Length + b.Length);
            c.WriteBuff(a);
            c.WriteBuff(b);
            return c.toBytes();
        }




    }
}
