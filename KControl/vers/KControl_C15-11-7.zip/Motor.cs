﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KeyMove.Tools;

namespace KControl
{
    class Motor
    {

        public static double[] scaleAngle = new double[] { 360F / 10000, 360F / 10000, 360F / 10000, 360F / 10000, 360F / 10000, 360F / 10000 };
        public static double[] offsetAngle = new double[] { 0, 0, 0, 0, 0, 0 };

        public static bool Enable { get; set; }

        static UartProtocol UP;
        static List<double[]> pluslist;
        static int Count;
        static int Index;

        public static int StartSpeed { get; set; }
        public static int SpeedTime { get; set; }
        public static int Frequency { get; set; }

        static int _Pluse;
        public static int PlusToDeg { private get { return _Pluse; }
            set
            {
                _Pluse = value;
                scaleAngle = new double[] { 360F / value, 360F / value, 360F / value, 360F / value, 360F / value, 360F / value };
            }
        }



        public static bool isReady=false;

        public static void Init(UartProtocol up)
        {
            SpeedTime = 200;
            StartSpeed = 500;
            PlusToDeg = 100000;
            Frequency = 10000;

            UP = up;
            Enable = false;
            up.RegisterCmdEvent(UartProtocol.PacketCmd.LoadPluseList, (UartProtocol.PacketStats stats,byte[] buff) => {
                switch (stats)
                {
                    case UartProtocol.PacketStats.RecvOK:
                        ByteStream s = new ByteStream(buff);
                        int flag = s.ReadByte();
                        if (flag == 0xaa)
                        {
                            Count = Index = 0;
                            isReady = true;
                            return;
                        }
                        int index = s.ReadWord();
                        if (flag == 0x55)
                        {
                            Index = index;
                        }
                        if (Count <= 0)
                        {
                            return;
                        }
                        int bufflen = s.ReadDWorde();
                        if (bufflen > 48) bufflen = 2; else bufflen /= 12;
                        if (bufflen > Count) bufflen = Count;
                        s = new ByteStream(52);
                        s.WriteWord(bufflen);
                        s.WriteWord(Index);
                        Count -= bufflen;
                        if (Count == 0)
                        {

                        }
                        for (int i = 0; i < bufflen; i++)
                        {
                            double[] ag = pluslist[Index++];
                            int[] v = AngleToPluse(ag);
                            for (int j = 0; j < 6; j++)
                                s.WriteDWord(v[j]);
                        }
                        UP.SendDataPacket(UartProtocol.PacketCmd.LoadPluseList, s.toBytes());
                        break;
                    case UartProtocol.PacketStats.RecvError:
                        break;
                    case UartProtocol.PacketStats.RecvTimeOut:

                        break;
                }
            });

            UartProtocol.UartFunction act = (UartProtocol.PacketStats stats, byte[] buff) => {
                switch (stats)
                {
                    case UartProtocol.PacketStats.RecvOK:
                        if (buff[0] == 0xaa)
                        {
                            isReady = true;
                        }
                        break;
                    case UartProtocol.PacketStats.RecvError:
                        break;
                    case UartProtocol.PacketStats.RecvTimeOut:
                        break;
                }
            };

            up.RegisterCmdEvent(UartProtocol.PacketCmd.LoadPluse, act);

            up.RegisterCmdEvent(UartProtocol.PacketCmd.SetupPWMOption, (UartProtocol.PacketStats stats, byte[] buff) => {
                switch (stats)
                {
                    case UartProtocol.PacketStats.RecvOK:
                        isReady = true;
                        break;
                    case UartProtocol.PacketStats.RecvError:
                        break;
                    case UartProtocol.PacketStats.RecvTimeOut:
                        break;
                }
            });
        }

        public static int[] AngleToPluse(double[] angle)
        {
            int[] p = new int[6];
            for (int i = 0; i < 6; i++)
            {
                p[i] = (int)((angle[i] + offsetAngle[i]) / scaleAngle[i]);
            }
            return p;
        }

        public static void MotorRun(double[] angle)
        {
            if (!Enable) return;
            ByteStream b = new ByteStream(30);
            int[] p = new int[6];
            for (int i = 0; i < 6; i++)
            {
                int plus= (int)((angle[i] + offsetAngle[i]) / scaleAngle[i]);
                b.WriteDWord(plus);
            }
            UP.SendDataPacket(UartProtocol.PacketCmd.LoadPluse, b.toBytes());
            isReady = false;
        }

        public static void MotorRunList(List<double[]> list)
        {
            if (!Enable) return;
            pluslist = list;
            Index = 1;
            Count = list.Count - 1;
            ByteStream b = new ByteStream(28);
            b.WriteWord(0);
            b.WriteWord(Count);
            int[] vp = AngleToPluse(list[0]);
            for (int i = 0; i < 6; i++)
                b.WriteDWord(vp[i]);
            UP.SendDataPacket(UartProtocol.PacketCmd.LoadPluseList, b.toBytes());
            isReady = false;
        }

        public static void MotorStop()
        {
            if (!Enable) return;
            UP.SendCmdPacket(UartProtocol.PacketCmd.RunStop);
            isReady = true;
        }

        public static void MotorFastStop()
        {
            if (!Enable) return;
            UP.SendCmdPacket(UartProtocol.PacketCmd.PWMStop);
        }

        public static void SetInfo( int sp, int MaxSpeed, int time)
        {
            if (!Enable) return;
            StartSpeed = sp;
            Frequency = MaxSpeed;
            SpeedTime = time;
            ByteStream b = new ByteStream(10);
            b.WriteWord(StartSpeed);
            b.WriteDWord(Frequency);
            b.WriteWord(SpeedTime);
            UP.SendDataPacket(UartProtocol.PacketCmd.SetupPWMOption, b.toBytes());
            isReady = false;
        }
        public static void SetInfo()
        {
            if (!Enable) return;
            ByteStream b = new ByteStream(10);
            b.WriteWord(StartSpeed);
            b.WriteDWord(Frequency);
            b.WriteWord(SpeedTime);
            UP.SendDataPacket(UartProtocol.PacketCmd.SetupPWMOption, b.toBytes());
            isReady = false;
        }
    }
}
