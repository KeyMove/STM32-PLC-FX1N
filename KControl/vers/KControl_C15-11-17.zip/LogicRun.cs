﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace KControl
{
    class LogicRun
    {

        enum Mode:int{
            G0=0,
            G1=1,
            Delay=2,
            SetSpeed=3,
            SetRange=4,
            OUT=5,
            IN=6,
        }

        public static bool sumlot=true;
        public static bool looprun = true;
        static double speed=10;
        static double rg=0.1;
        static bool First;
        static bool TaskThread = false;

        static bool isRun = false;
        public static bool IsRun {
            get { return isRun; }
            private set { }
        }
        static int Index;
        static int DefDelay = 20;
        public static List<ModeObject> LogicList=new List<ModeObject>();
        public static Axis6.AxisStruct LastStruct;
        static Axis6.AxisStruct RunLastStruct;
        public class ModeObject{
            public string message;
            public virtual void run() { }
            public virtual void del() { }
            public virtual void line() { }
            public virtual void remove() { }
        }

        public class GList : ModeObject
        {
            public Axis6.AxisStruct sour;
            public Axis6.AxisStruct dest;
            public object linehandl;
            public object drawhandle;
            int count = 0;
            int bcount = 0;
            int docount = 0;
            List<double[]> aglist = new List<double[]>();
            Axis6.AxisStruct[] list;
            double[][] poslist;
            double[][] destangle;
            double N, O, A;
            public GList()
            {


            }

            public GList(double[] Xl,double[] Yl,double[] Zl,Axis6.AxisStruct last)
            {
                poslist = new double[3][];
                poslist[0] = Xl;
                poslist[1] = Yl;
                poslist[2] = Zl;
                count = Xl.Length;
                bcount = 1;
                docount= 0;
                N = last.N;
                O = last.O;
                A = last.A;
                destangle = new double[count][];
                destangle[0] = Axis6.PosToAngle(LastStruct.angle, last.X, last.Y, last.Z, N, O, A);
                if(destangle[0]!=null)
                    LastStruct.angle = destangle[0];
                linehandl=Axis6.DrawLineList(Xl, Yl, Zl);
            }

            public override void run()
            {

                Task.Run(() => {
                    while (isRun)
                    {
                        if (bcount < count)
                        {
                            double[] value;
                            destangle[bcount] = value = Axis6.PosToAngle(LastStruct.angle, poslist[0][bcount], poslist[1][bcount], poslist[2][bcount], N, O, A);
                            if (value == null)
                                destangle[bcount] = destangle[bcount - 1];
                            bcount++;
                        }
                        else
                            break;
                    }
                });
                while (isRun)
                {
                    if (Motor.isReady || !Motor.Enable)
                    {
                        if (docount < bcount)
                        {
                            Motor.MotorRun(destangle[docount]);
                            Axis6.MoveToAngle(destangle[docount]);
                            docount++;
                        }
                    }
                    Thread.Sleep(1);
                }
                LastStruct.angle=destangle[count-1];
                //Axis6.AxisStruct last = new Axis6.AxisStruct();

            }

            public override string ToString()
            {
                return "G代码\r\n长度" + count;
            }

            public override void del()
            {
                if (linehandl != null)
                    Axis6.removeLine(linehandl);
            }

            public override void remove()
            {
                if (linehandl != null)
                    Axis6.removeLine(linehandl);
                if (drawhandle != null)
                    Axis6.removeLine(drawhandle);
                linehandl = drawhandle = null;
            }

        }

        public class G0 : ModeObject
        {
            public Axis6.AxisStruct sour;
            public Axis6.AxisStruct dest;
            public object linehandl;
            public object drawhandle;
            public G0(Axis6.AxisStruct start,Axis6.AxisStruct stop)
            {
                sour = start;
                dest = stop;
                drawhandle = Axis6.DrawArcLine(sour.angle, dest.angle);
                LastStruct = dest;
            }

            public G0(Axis6.AxisStruct stop)
            {
                sour = LastStruct;
                dest = stop;
                drawhandle = Axis6.DrawArcLine(sour.angle, dest.angle);
                LastStruct = dest;
            }

            public override void run()
            {
                Motor.MotorRun(dest.angle);
                if (sumlot)
                {
                    if (First)
                        linehandl=Axis6.MoveArc(sour.angle, dest.angle, 'b', 2, 15, true);
                    else
                        Axis6.MoveArc(LastStruct.angle, dest.angle, 'b', 2, 15, false);
                }
                LastStruct = dest;
                //Thread.Sleep(DefDelay);
            }

            public override void remove()
            {
                if (linehandl != null)
                    Axis6.removeLine(linehandl);
                if (drawhandle != null)
                    Axis6.removeLine(drawhandle);
                linehandl = drawhandle = null;
            }

            public override void del()
            {
                if (linehandl != null)
                    Axis6.removeLine(linehandl);
            }

            public override void line()
            {
                if (drawhandle != null)
                    Axis6.removeLine(drawhandle);
                drawhandle = Axis6.DrawArcLine(sour.angle, dest.angle);
            }

            public override string ToString()
            {
                
                return "弧线运动到点 :\r\n起点:" + sour + "\r\n终点:" + dest + "\r\n运动速度:" + speed.ToString("f4") + "KHz  " + message;
            }
        }

        public class G1 : ModeObject
        {
            public Axis6.AxisStruct sour;
            public Axis6.AxisStruct dest;
            List<double[]> AngleList;
            object lineObj;
            public object linehandl;
            public object drawhandle;
            public G1(Axis6.AxisStruct start, Axis6.AxisStruct stop)
            {
                sour = start;
                dest = stop;
                drawhandle = Axis6.DrawLine(sour, dest);
                LastStruct = dest;
            }

            public G1(Axis6.AxisStruct stop)
            {
                sour = LastStruct;
                dest = stop;
                drawhandle=Axis6.DrawLine(sour, dest);
                LastStruct = dest;
            }

            public override void run()
            {
                if(AngleList==null)
                {
                    AngleList = Axis6.PointToPointLineAngle(sour, dest, rg);
                    lineObj = Axis6.AngleListToObject(AngleList);
                }
                Motor.MotorRunList(AngleList);
                if (sumlot)
                {
                    if (First)
                        linehandl=Axis6.DrawLine(sour, dest,'b',2);
                    //foreach (double[] ag in AngleList)
                    //{
                    //    Axis6.MoveToAngle(ag);
                    //    //Thread.Sleep(10);
                    //    if (!isRun)
                    //        break;
                    //}
                    Axis6.PointToPointMove(lineObj);
                }
                LastStruct = dest;
                //Thread.Sleep(DefDelay);
            }

            public override void remove()
            {
                if (linehandl != null)
                    Axis6.removeLine(linehandl);
                if (drawhandle != null)
                    Axis6.removeLine(drawhandle);
                linehandl = drawhandle = null;
            }

            public override void del()
            {
                if (linehandl != null)
                    Axis6.removeLine(linehandl);
            }

            public override void line()
            {
                if (drawhandle != null)
                    Axis6.removeLine(drawhandle);
                drawhandle = Axis6.DrawLine(sour, dest);
            }

            public override string ToString()
            {
                return "直线运动到点 :\r\n起点:" + sour + "\r\n终点:" + dest + "\r\n运动速度:" + speed + "KHz\r\n精度:" + rg + "mm  "+message;
            }
        }

        public class Delay : ModeObject
        {
            int time;
            public Delay(int t)
            {
                time = t;
            }
            public override void run()
            {
                DefDelay = time;
                Thread.Sleep(time);
            }

            public override string ToString()
            {
                return "运动延时" + time + "毫秒  " + message;
            }
        }

        public class SetSpeed : ModeObject
        {
            int speed;
            public SetSpeed(int s)
            {
                speed = s;
            }
            public override void run()
            {
                Motor.Frequency = speed * 1000;
                Motor.SetInfo();
            }
            public override string ToString()
            {
                return "设置运行速度"+speed+"KHz  " + message;
            }
        }

        public class SetRange : ModeObject
        {
            double r;
            public SetRange(double r)
            {
                this.r = r;
            }
            public override void run()
            {
                rg = r/1000;
            }
            public override string ToString()
            {
                return "设置运行精度为"+r+"mm  " + message;
            }
        }

        static public void Add(ModeObject obj)
        {
            LastStruct = (obj is G0) ? ((G0)obj).dest : (obj is G1) ? ((G1)obj).dest : LastStruct;
            LogicList.Add(obj);
        }

        static public void Insert(int index,ModeObject obj)
        {
            LogicList.Insert(index,obj);
        }

        static public void Clear()
        {
            LastStruct = Axis6.DefStruct;
            foreach(ModeObject m in LogicList)
            {
                m.remove();
            }
            LogicList.Clear();
        }

        static void UpdateLine()
        {
            LastStruct = Axis6.DefStruct;
            foreach (ModeObject o in LogicList)
            {
                if (o is G0)
                {
                    ((G0)o).sour = LastStruct;
                    LastStruct = ((G0)o).dest;
                    o.line();
                }
                else if (o is G1)
                {
                    ((G1)o).sour = LastStruct;
                    LastStruct = ((G1)o).dest;
                    o.line();
                }
            }
        }

        static public void Remove(ModeObject obj)
        {
            int index = LogicList.IndexOf(obj);
            if (index == -1) return;
            if(obj is G0 || obj is G1)
            {
                obj.remove();
                LogicList.RemoveAt(index);
                UpdateLine();
            }
            else
                LogicList.RemoveAt(index);
        }


        static public void Start()
        {
            if (isRun) return;
            Index = 0;
            isRun = true;
            First = true;
            //ModeObject start=null;            
            
            RunLastStruct = Axis6.DefStruct;
            if(!TaskThread)
            Task.Run(() => {
                TaskThread = true;
                while (TaskThread)
                {
                    if (isRun)
                    {
                        if (Motor.isReady || !Motor.Enable)
                        {
                            if (Index >= LogicList.Count)
                            {
                                if (looprun)
                                {
                                    Index = 0;
                                    Thread.Sleep(200);
                                }
                                else Stop();
                                First = false;
                                continue;
                            }
                            LogicList[Index++].run();
                            
                        }
                        else
                            Thread.Sleep(10);
                        //while (!Motor.isReady);
             
                    }
                    else
                    {
                        Thread.Sleep(100);
                    }
                }
            });
            
    }

        static public void Stop()
        {
            isRun = false;
            foreach (ModeObject obj in LogicList)
                obj.del();
            Motor.MotorStop();
        }

        static public void StopLogic()
        {
            TaskThread = false;
        }

    }
}
